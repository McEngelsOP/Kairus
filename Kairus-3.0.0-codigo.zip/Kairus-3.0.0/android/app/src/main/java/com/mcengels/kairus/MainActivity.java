package com.mcengels.kairus;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
