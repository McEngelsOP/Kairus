import { strFromU8, strToU8, unzipSync, zipSync } from "fflate";
import { backup, parseBackup } from "./model.js";

export const MAX_BACKUP_BYTES = 64 * 1024 * 1024;
const ENTRY = "kairus-backup-v2.json";
const invalid = "El archivo no es una copia válida de Kairus.";

export function createBackupFile(ledger) {
  const data = strToU8(backup(ledger));
  if (data.length > MAX_BACKUP_BYTES - 64 * 1024)
    throw new Error("Tu registro supera los 64 MB permitidos para una copia.");
  return zipSync({ [ENTRY]: data }, { level: 6 });
}

export function readBackupFile(bytes) {
  if (bytes.length > MAX_BACKUP_BYTES)
    throw new Error("Selecciona una copia de hasta 64 MB.");
  const isArchive = bytes[0] === 0x50 && bytes[1] === 0x4b;
  let imported;
  try {
    const data = isArchive
      ? unzipSync(bytes, {
          filter: file => file.name === ENTRY && file.originalSize <= MAX_BACKUP_BYTES,
        })[ENTRY]
      : bytes;
    if (!data) throw new Error(invalid);
    imported = parseBackup(strFromU8(data), MAX_BACKUP_BYTES);
  } catch {
    throw new Error(invalid);
  }
  if (imported.categories.some(category => category.id === "transfer"))
    throw new Error(invalid);
  return imported;
}
