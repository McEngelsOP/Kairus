// The ledger uses integer cents. Transfers move money between accounts and never count as income.
export const VERSION = 1;
export const MAX_CENTS = 9999999999;
export const CURRENCIES = [
  "PEN",
  "USD",
  "EUR",
  "MXN",
  "COP",
  "CLP",
  "ARS",
  "BRL",
  "CNY", "RUB", "GBP", "JPY", "CAD", "CHF",
];
export const COLORS = [
  "#69d5aa",
  "#e7b66b",
  "#b3a1e8",
  "#e596ac",
  "#8cc9df",
  "#ffd93d",
];
export const uid = () => {
  if (typeof crypto.randomUUID === "function") return crypto.randomUUID();
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  bytes[6] = (bytes[6] & 15) | 64;
  bytes[8] = (bytes[8] & 63) | 128;
  const hex = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join(
    "",
  );
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
};
export const today = () => localDate(new Date());
export function localDate(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
export function validDate(s) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(s + "T12:00:00");
  return (
    Number.isFinite(d.getTime()) &&
    localDate(d) === s &&
    s >= "1900-01-01" &&
    s <= "2199-12-31"
  );
}
const assert = (condition, message) => {
  if (!condition) throw new Error(message);
};
const text = (v, max = 100) => typeof v === "string" && v.length <= max;
const idOK = (v) => typeof v === "string" && /^[a-zA-Z0-9_-]{1,100}$/.test(v) && !(v in Object.prototype);
const centsOK = (n) => Number.isSafeInteger(n) && Math.abs(n) <= MAX_CENTS;
export function initialState() {
  return {
    version: VERSION,
    revision: 0,
    settings: {
      name: "",
      currency: "PEN",
      language: "es",
      theme: "dark",
      iconStyle: "color",
      reminder: "",
    },
    accounts: [{ id: "cash", name: "Efectivo", initial: 0, archived: false }],
    categories: [
      ["food", "Alimentación", "expense", "food", 0],
      ["transport", "Transporte", "expense", "bus", 4],
      ["home", "Hogar", "expense", "home", 1],
      ["health", "Salud", "expense", "heart", 3],
      ["education", "Educación", "expense", "book", 2],
      ["fun", "Ocio", "expense", "spark", 5],
      ["shopping", "Compras", "expense", "bag", 3],
      ["other-expense", "Otros gastos", "expense", "grid", 4],
      ["salary", "Sueldo", "income", "wallet", 5],
      ["freelance", "Trabajo independiente", "income", "briefcase", 0],
      ["gift", "Regalos", "income", "gift", 2],
      ["other-income", "Otros ingresos", "income", "plus", 4],
    ].map(([id, name, type, icon, c]) => ({
      id,
      name,
      type,
      icon,
      color: COLORS[c],
      archived: false,
    })),
    transactions: [],
    budgets: {},
    recurring: [],
  };
}
export const ICON_NAMES = [
  "food",
  "bus",
  "home",
  "heart",
  "book",
  "spark",
  "bag",
  "grid",
  "wallet",
  "briefcase",
  "gift",
  "plus",
];

export function parseMoney(value, signed = false) {
  const s = String(value).trim().replace(",", ".");
  assert(
    (signed ? /^-?\d{1,8}(?:\.\d{1,2})?$/ : /^\d{1,8}(?:\.\d{1,2})?$/).test(s),
    "Usa un importe válido con hasta dos decimales.",
  );
  const negative = s.startsWith("-"),
    [a, b = ""] = s.replace("-", "").split(".");
  const n = (Number(a) * 100 + Number(b.padEnd(2, "0"))) * (negative ? -1 : 1);
  assert(centsOK(n), "El importe supera el límite permitido.");
  return n;
}
export function calculate(expression) {
  const s = String(expression)
    .replace(/\s/g, "")
    .replaceAll(",", ".")
    .replaceAll("×", "*")
    .replaceAll("÷", "/")
    .replaceAll("−", "-");
  assert(
    s.length <= 100 && /^[\d.+*/()-]+$/.test(s),
    "Revisa la operación de la calculadora.",
  );
  const tokens = s.match(/\d+(?:\.\d+)?|[()+*/-]/g) || [];
  assert(tokens.join("") === s, "Revisa la operación de la calculadora.");
  let pos = 0;
  function atom() {
    const token = tokens[pos++];
    if (token === "-") return -atom();
    if (token === "+") return atom();
    if (token === "(") {
      const n = expressionValue();
      assert(tokens[pos++] === ")", "Falta cerrar un paréntesis.");
      return n;
    }
    assert(token != null && /^\d/.test(token), "La operación está incompleta.");
    return Number(token);
  }
  function product() {
    let n = atom();
    while (["*", "/"].includes(tokens[pos])) {
      const op = tokens[pos++],
        d = atom();
      assert(op !== "/" || d !== 0, "No se puede dividir entre cero.");
      n = op === "*" ? n * d : n / d;
    }
    return n;
  }
  function expressionValue() {
    let n = product();
    while (["+", "-"].includes(tokens[pos])) {
      const op = tokens[pos++],
        d = product();
      n = op === "+" ? n + d : n - d;
    }
    return n;
  }
  const n = expressionValue();
  assert(
    pos === tokens.length &&
      Number.isFinite(n) &&
      Math.abs(n * 100) <= MAX_CENTS,
    "Revisa la operación de la calculadora.",
  );
  return (Math.round((n + Number.EPSILON) * 100) / 100).toFixed(2);
}

export function validateTransaction(s, t) {
  assert(
    idOK(t.id) && ["income", "expense", "transfer"].includes(t.type),
    "Movimiento no válido.",
  );
  assert(validDate(t.date), "Selecciona una fecha válida.");
  assert(
    centsOK(t.amount) && t.amount > 0,
    "El importe debe ser mayor que cero.",
  );
  assert(
    s.accounts.some((a) => a.id === t.account),
    "Selecciona una cuenta.",
  );
  if (t.type === "transfer") {
    assert(
      t.to !== t.account && s.accounts.some((a) => a.id === t.to),
      "Elige dos cuentas diferentes para la transferencia.",
    );
    assert(t.category === "", "La transferencia no lleva categoría.");
  } else
    assert(
      s.categories.some((c) => c.id === t.category && c.type === t.type),
      "Selecciona una categoría del tipo correcto.",
    );
  assert(text(t.note, 500), "La nota puede tener hasta 500 caracteres.");
  assert(
    !t.receipt ||
      (text(t.receipt, 400000) &&
        /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(t.receipt)),
    "El comprobante debe ser una imagen pequeña.",
  );
}
export function validateState(s) {
  assert(
    s && s.version === VERSION,
    "Esta copia no es compatible con esta versión de Kairus.",
  );
  assert(
    Number.isSafeInteger(s.revision) && s.revision >= 0,
    "Revisión de datos no válida.",
  );
  const p = s.settings;
  assert(
    p &&
      text(p.name, 40) &&
      CURRENCIES.includes(p.currency) &&
      ["es", "en", "fr", "ru", "zh", "pt"].includes(p.language) &&
      ["dark", "light", "system"].includes(p.theme) &&
      ["color", "mono"].includes(p.iconStyle) &&
      (p.reminder === "" || /^([01]\d|2[0-3]):[0-5]\d$/.test(p.reminder)),
    "Preferencias no válidas.",
  );
  assert(
    Array.isArray(s.accounts) &&
      s.accounts.length > 0 &&
      s.accounts.length <= 100 &&
      s.accounts.some((a) => !a.archived),
    "Debe existir al menos una cuenta activa.",
  );
  assert(
    Array.isArray(s.categories) &&
      s.categories.length <= 200 &&
      Array.isArray(s.transactions) &&
      s.transactions.length <= 50000 &&
      Array.isArray(s.recurring) &&
      s.recurring.length <= 200,
    "La copia supera los límites del registro personal.",
  );
  for (const list of [s.accounts, s.categories, s.transactions, s.recurring])
    assert(
      new Set(list.map((x) => x.id)).size === list.length &&
        list.every((x) => idOK(x.id)),
      "La copia contiene identificadores duplicados o no válidos.",
    );
  for (const a of s.accounts)
    assert(
      text(a.name, 40) &&
        a.name.trim() &&
        centsOK(a.initial) &&
        typeof a.archived === "boolean",
      "Cuenta no válida.",
    );
  for (const c of s.categories)
    assert(
      text(c.name, 40) &&
        c.name.trim() &&
        ["expense", "income"].includes(c.type) &&
        ICON_NAMES.includes(c.icon) &&
        COLORS.includes(c.color) &&
        typeof c.archived === "boolean",
      "Categoría no válida.",
    );
  for (const t of s.transactions) validateTransaction(s, t);
  assert(
    s.budgets && typeof s.budgets === "object" && !Array.isArray(s.budgets),
    "Presupuestos no válidos.",
  );
  for (const [month, amount] of Object.entries(s.budgets))
    assert(
      validDate(month + "-01") && centsOK(amount) && amount >= 0,
      "Presupuesto no válido.",
    );
  for (const r of s.recurring) {
    assert(
      validDate(r.nextDate) &&
        ["weekly", "monthly", "yearly"].includes(r.frequency) &&
        Number.isInteger(r.day) &&
        r.day >= 1 &&
        r.day <= 31 &&
        typeof r.active === "boolean",
      "Repetición no válida.",
    );
    validateTransaction(s, { ...r, id: r.id, date: r.nextDate });
  }
  assert(
    new TextEncoder().encode(JSON.stringify(s)).length <= 3500000,
    "Tu registro alcanzó el límite de almacenamiento. Exporta una copia y elimina comprobantes antiguos.",
  );
  return s;
}
export function putTransaction(s, input) {
  const t = {
    id: input.id || uid(),
    type: input.type,
    amount: input.amount,
    date: input.date,
    account: input.account,
    to: input.type === "transfer" ? input.to : "",
    category: input.type === "transfer" ? "" : input.category,
    note: input.note || "",
    receipt: input.receipt || "",
  };
  validateTransaction(s, t);
  const i = s.transactions.findIndex((x) => x.id === t.id);
  if (i < 0) s.transactions.push(t);
  else s.transactions[i] = t;
  return t;
}
export function accountBalance(s, id, asOf = "2199-12-31") {
  const a = s.accounts.find((a) => a.id === id);
  if (!a) return 0;
  return s.transactions
    .filter((t) => t.date <= asOf)
    .reduce(
      (n, t) =>
        n +
        (t.account === id ? (t.type === "income" ? t.amount : -t.amount) : 0) +
        (t.type === "transfer" && t.to === id ? t.amount : 0),
      a.initial,
    );
}
export function monthly(s, month) {
  const items = s.transactions.filter((t) => t.date.startsWith(month));
  const income = items
    .filter((t) => t.type === "income")
    .reduce((n, t) => n + t.amount, 0);
  const expense = items
    .filter((t) => t.type === "expense")
    .reduce((n, t) => n + t.amount, 0);
  return {
    items,
    income,
    expense,
    balance: income - expense,
    budget: s.budgets[month] || 0,
  };
}
export function categoryTotals(s, month, type = "expense") {
  const totals = new Map();
  for (const t of monthly(s, month).items.filter((x) => x.type === type))
    totals.set(t.category, (totals.get(t.category) || 0) + t.amount);
  return [...totals]
    .map(([id, amount]) => ({
      ...s.categories.find((c) => c.id === id),
      amount,
    }))
    .sort((a, b) => b.amount - a.amount);
}
export function nextOccurrence(date, frequency, day = +date.slice(8)) {
  const d = new Date(date + "T12:00:00");
  if (frequency === "weekly") d.setDate(d.getDate() + 7);
  else {
    d.setDate(1);
    if (frequency === "monthly") d.setMonth(d.getMonth() + 1);
    else d.setFullYear(d.getFullYear() + 1);
    const max = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
    d.setDate(Math.min(day, max));
  }
  return localDate(d);
}
export function completeRecurring(s, id, skip = false) {
  const r = s.recurring.find((x) => x.id === id && x.active);
  assert(r, "No se encontró la repetición.");
  assert(r.nextDate <= today(), "El movimiento todavía no vence.");
  const occurrenceId = `r_${r.id}_${r.nextDate}`;
  if (!skip && !s.transactions.some((t) => t.id === occurrenceId))
    putTransaction(s, { ...r, id: occurrenceId, date: r.nextDate });
  r.nextDate = nextOccurrence(r.nextDate, r.frequency, r.day);
}
export function csv(s) {
  // Quoting alone does not stop spreadsheet formulas: neutralize formula-leading text.
  const field = (v) => {
    const value = String(v ?? "");
    return (
      '"' +
      (/^(?:\s*[=+@\-]|[\t\r\n])/.test(value) ? "'" + value : value).replaceAll(
        '"',
        '""',
      ) +
      '"'
    );
  };
  const rows = [
    [
      "Fecha",
      "Tipo",
      "Importe",
      "Moneda",
      "Cuenta",
      "Destino",
      "Categoría",
      "Nota",
    ],
  ];
  for (const t of [...s.transactions].sort((a, b) =>
    a.date.localeCompare(b.date),
  ))
    rows.push([
      t.date,
      t.type,
      (t.amount / 100).toFixed(2),
      s.settings.currency,
      s.accounts.find((a) => a.id === t.account)?.name,
      s.accounts.find((a) => a.id === t.to)?.name,
      s.categories.find((c) => c.id === t.category)?.name,
      t.note,
    ]);
  return "\uFEFF" + rows.map((row) => row.map(field).join(",")).join("\r\n");
}
export function parseBackup(raw, maxLength = 4000000) {
  assert(
    typeof raw === "string" && raw.length <= maxLength,
    "La copia es demasiado grande.",
  );
  let data;
  try {
    data = JSON.parse(raw);
  } catch {
    throw new Error("El archivo no contiene una copia JSON válida.");
  }
  assert(
    data?.app === "Kairus" && data.data,
    "Selecciona una copia exportada desde Kairus.",
  );
  return validateState(data.data);
}
export function backup(s) {
  return JSON.stringify({
    app: "Kairus",
    exportedAt: new Date().toISOString(),
    data: s,
  });
}
export function quickEntry(s, sentence) {
  const match = String(sentence).match(
    /(?:s\/\.?|\$|€)?\s*(\d{1,8}(?:[.,]\d{1,2})?)/i,
  );
  assert(
    match,
    "Incluye un importe. Por ejemplo: gasté 18,50 en alimentación.",
  );
  const type =
    /\b(ingres[oó]|cobr[eé]|recib[ií]|sueldo|salary|income|earned)\b/i.test(
      sentence,
    )
      ? "income"
      : "expense";
  const normalized = sentence
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
  const found = s.categories.find(
    (c) =>
      !c.archived &&
      c.type === type &&
      normalized.includes(
        c.name
          .normalize("NFD")
          .replace(/[\u0300-\u036f]/g, "")
          .toLowerCase(),
      ),
  );
  const aliases = [
    [/comida|almuerzo|cena|desayuno|food/, "food"],
    [/taxi|bus|pasaje|transport/, "transport"],
    [/sueldo|salary/, "salary"],
    [/salud|farmacia/, "health"],
  ];
  const category =
    found?.id ||
    aliases.find(
      ([r, id]) =>
        r.test(normalized) &&
        s.categories.some((c) => c.id === id && c.type === type),
    )?.[1] ||
    s.categories.find((c) => c.type === type && !c.archived)?.id;
  return {
    type,
    amount: parseMoney(match[1]),
    date: today(),
    account: s.accounts.find((a) => !a.archived).id,
    category,
    note: sentence.slice(0, 500),
  };
}
