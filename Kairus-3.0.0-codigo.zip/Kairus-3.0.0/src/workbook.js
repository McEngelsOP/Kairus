import { zipSync, strToU8 } from "fflate";
import { accountBalance } from "./model.js";

export const EXCEL_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
const main = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
const rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
const pkg = "http://schemas.openxmlformats.org/package/2006";
const drawing = "http://schemas.openxmlformats.org/drawingml/2006";
const types = { expense: "Gasto", income: "Ingreso", transfer: "Transferencia" };

const xml = value => String(value)
  .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\ud800-\udfff\ufffe\uffff]/gu, "")
  .replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;" })[char]);
const documentXml = content => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' + content;
const column = index => String.fromCharCode(65 + index);
const excelDate = date => (Date.parse(date + "T00:00:00Z") - Date.UTC(1899, 11, 30)) / 86400000 - (date < "1900-03-01" ? 1 : 0);
const relationships = entries => `<Relationships xmlns="${pkg}/relationships">${entries.map(([type, target], i) =>
  `<Relationship Id="rId${i + 1}" Type="${rel}/${type}" Target="${target}"/>`).join("")}</Relationships>`;

function cell(value, ref, style) {
  if (typeof value === "number") return `<c r="${ref}" s="${style}"><v>${value}</v></c>`;
  return `<c r="${ref}" s="${style}" t="inlineStr"><is><t xml:space="preserve">${xml(value)}</t></is></c>`;
}

function worksheet({ title, subtitle, headers, rows, widths, formats = {}, dashboard = false }) {
  const allRows = [[title], [subtitle], [], headers, ...rows];
  const lastColumn = column(headers.length - 1);
  const rowsXml = allRows.map((row, i) => {
    const index = i + 1;
    const height = i === 0 ? ' ht="31" customHeight="1"' : i === 3 ? ' ht="24" customHeight="1"' : "";
    return `<row r="${index}"${height}>${row.map((value, j) => {
      const style = i < 4 ? [1, 2, 0, 3][i] : (formats[j] || 4) + (i % 2);
      return cell(value, column(j) + index, style);
    }).join("")}</row>`;
  }).join("");
  return `<worksheet xmlns="${main}" xmlns:r="${rel}">
  <sheetViews><sheetView showGridLines="0" workbookViewId="0">${dashboard ? "" : '<pane ySplit="4" topLeftCell="A5" activePane="bottomLeft" state="frozen"/>'}</sheetView></sheetViews>
  <sheetFormatPr defaultRowHeight="19"/>
  <cols>${widths.map((width, i) => `<col min="${i + 1}" max="${i + 1}" width="${width}" customWidth="1"/>`).join("")}</cols>
  <sheetData>${rowsXml}</sheetData>
  ${!dashboard && rows.length ? `<autoFilter ref="A4:${lastColumn}${allRows.length}"/>` : ""}
  <mergeCells count="2"><mergeCell ref="A1:${lastColumn}1"/><mergeCell ref="A2:${lastColumn}2"/></mergeCells>
  ${dashboard ? '<drawing r:id="rId1"/>' : ""}
  </worksheet>`;
}

function styles(currency) {
  const fill = color => `<fill><patternFill patternType="solid"><fgColor rgb="FF${color}"/><bgColor indexed="64"/></patternFill></fill>`;
  const font = (size, color, bold = false) => `<font>${bold ? "<b/>" : ""}<sz val="${size}"/><color rgb="FF${color}"/><name val="Calibri"/></font>`;
  const xf = (fontId, fillId, numFmtId = 0) =>
    `<xf numFmtId="${numFmtId}" fontId="${fontId}" fillId="${fillId}" borderId="0" xfId="0" applyAlignment="1"${numFmtId ? ' applyNumberFormat="1"' : ""}><alignment vertical="center"/></xf>`;
  return `<styleSheet xmlns="${main}">
  <numFmts count="2"><numFmt numFmtId="164" formatCode="${xml(`"${currency}" #,##0.00;"${currency}" -#,##0.00`)}"/><numFmt numFmtId="165" formatCode="dd/mm/yyyy"/></numFmts>
  <fonts count="4">${font(11, "242424")}${font(20, "FFD93D", true)}${font(11, "626262")}${font(11, "FFFFFF", true)}</fonts>
  <fills count="5"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>${fill("222222")}${fill("343434")}${fill("F6F3E9")}</fills>
  <borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="10">${[
    xf(0, 0), xf(1, 2), xf(2, 0), xf(3, 3),
    xf(0, 0), xf(0, 4), xf(0, 0, 164), xf(0, 4, 164), xf(0, 0, 165), xf(0, 4, 165),
  ].join("")}</cellXfs>
  <cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
}

function chartTitle(title) {
  return `<c:title><c:tx><c:rich><a:bodyPr/><a:lstStyle/><a:p><a:r><a:rPr lang="es-PE" b="1"/><a:t>${xml(title)}</a:t></a:r></a:p></c:rich></c:tx><c:layout/><c:overlay val="0"/></c:title>`;
}

function chartRef(tag, formula, data, numeric = false) {
  const cache = numeric ? "num" : "str";
  return `<c:${tag}><c:${cache}Ref><c:f>${formula}</c:f><c:${cache}Cache>${numeric ? "<c:formatCode>General</c:formatCode>" : ""}<c:ptCount val="${data.length}"/>${data.map((value, i) => `<c:pt idx="${i}"><c:v>${xml(value)}</c:v></c:pt>`).join("")}</c:${cache}Cache></c:${cache}Ref></c:${tag}>`;
}

function barChart({ title, sheet, rows, start = 5, series, horizontal = false }) {
  const ref = index => `${sheet}!$${column(index)}$${start}:$${column(index)}$${start + rows.length - 1}`;
  const body = series.map(([index, name, color], i) =>
    `<c:ser><c:idx val="${i}"/><c:order val="${i}"/><c:tx><c:v>${name}</c:v></c:tx><c:spPr><a:solidFill><a:srgbClr val="${color}"/></a:solidFill></c:spPr>
    ${chartRef("cat", ref(0), rows.map(row => row[0]))}${chartRef("val", ref(index), rows.map(row => row[index]), true)}</c:ser>`).join("");
  return `<c:chartSpace xmlns:c="${drawing}/chart" xmlns:a="${drawing}/main"><c:chart>${chartTitle(title)}
  <c:plotArea><c:layout/><c:barChart><c:barDir val="${horizontal ? "bar" : "col"}"/><c:grouping val="clustered"/><c:varyColors val="0"/>${body}
  <c:gapWidth val="90"/><c:axId val="10"/><c:axId val="20"/></c:barChart>
  <c:catAx><c:axId val="10"/><c:scaling><c:orientation val="${horizontal ? "maxMin" : "minMax"}"/></c:scaling><c:axPos val="${horizontal ? "l" : "b"}"/><c:tickLblPos val="nextTo"/><c:crossAx val="20"/><c:crosses val="autoZero"/><c:auto val="1"/><c:lblAlgn val="ctr"/><c:lblOffset val="100"/></c:catAx>
  <c:valAx><c:axId val="20"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:axPos val="${horizontal ? "b" : "l"}"/><c:majorGridlines/><c:numFmt formatCode="#,##0.##" sourceLinked="0"/><c:tickLblPos val="nextTo"/><c:crossAx val="10"/><c:crosses val="${horizontal ? "max" : "autoZero"}"/><c:crossBetween val="between"/></c:valAx>
  </c:plotArea>${series.length > 1 ? '<c:legend><c:legendPos val="b"/><c:layout/><c:overlay val="0"/></c:legend>' : ""}
  <c:plotVisOnly val="1"/><c:dispBlanksAs val="gap"/></c:chart></c:chartSpace>`;
}

function chartDrawing() {
  const point = (tag, col, row) => `<xdr:${tag}><xdr:col>${col}</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>${row}</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:${tag}>`;
  return `<xdr:wsDr xmlns:xdr="${drawing}/spreadsheetDrawing" xmlns:a="${drawing}/main" xmlns:r="${rel}">
  ${[[7, 23], [24, 41]].map(([start, end], i) => `<xdr:twoCellAnchor>${point("from", 0, start)}${point("to", 5, end)}
    <xdr:graphicFrame macro=""><xdr:nvGraphicFramePr><xdr:cNvPr id="${i + 2}" name="Gráfico ${i + 1}"/><xdr:cNvGraphicFramePr/></xdr:nvGraphicFramePr><xdr:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/></xdr:xfrm><a:graphic><a:graphicData uri="${drawing}/chart"><c:chart xmlns:c="${drawing}/chart" r:id="rId${i + 1}"/></a:graphicData></a:graphic></xdr:graphicFrame>
    <xdr:clientData/></xdr:twoCellAnchor>`).join("")}</xdr:wsDr>`;
}

function workbookData(ledger, categoryLabel) {
  const accounts = new Map(ledger.accounts.map(account => [account.id, account.name]));
  const labels = new Map(ledger.categories.map(category => [category.id, categoryLabel(category)]));
  const months = new Map();
  const categories = new Map();
  let income = 0;
  let expense = 0;
  const movements = [...ledger.transactions].sort((a, b) => b.date.localeCompare(a.date)).map(t => {
    const period = t.date.slice(0, 7);
    const month = months.get(period) || { income: 0, expense: 0 };
    if (t.type !== "transfer") {
      month[t.type] += t.amount;
      categories.set(t.category, (categories.get(t.category) || 0) + t.amount);
      if (t.type === "income") income += t.amount;
      else expense += t.amount;
    }
    months.set(period, month);
    return [excelDate(t.date), types[t.type], labels.get(t.category) || "", t.amount / 100,
      accounts.get(t.account), accounts.get(t.to) || "", t.note, t.receipt ? "Sí" : "—"];
  });
  for (const period of Object.keys(ledger.budgets)) {
    if (!months.has(period)) months.set(period, { income: 0, expense: 0 });
  }
  const monthly = [...months.keys()].sort().map(period => {
    const { income, expense } = months.get(period);
    const budget = ledger.budgets[period] || 0;
    return [period, income / 100, expense / 100, (income - expense) / 100, budget / 100,
      budget ? (budget - expense) / 100 : ""];
  });
  const byCategory = ledger.categories.filter(c => categories.has(c.id))
    .sort((a, b) => a.type.localeCompare(b.type) || categories.get(b.id) - categories.get(a.id))
    .map(c => [labels.get(c.id), types[c.type], categories.get(c.id) / 100]);
  return { movements, monthly, byCategory, income, expense };
}

export function createWorkbook(ledger, categoryLabel = category => category.name) {
  const currency = ledger.settings.currency;
  const { movements, monthly, byCategory, income, expense } = workbookData(ledger, categoryLabel);
  const months = monthly.slice(-12);
  const top = byCategory.filter(row => row[1] === "Gasto").slice(0, 8);
  const sheets = [
    { name: "Resumen", title: "KAIRUS  /  Resumen financiero", dashboard: true,
      subtitle: movements.length ? `Historial completo · ${currency} · ${movements.length} movimientos` : `Sin movimientos registrados · ${currency}`,
      headers: ["Ingresos", "Gastos", "Balance", "Movimientos", "Moneda"], widths: [25, 22, 22, 20, 18],
      rows: [[income / 100, expense / 100, (income - expense) / 100, movements.length, currency]],
      formats: { 0: 6, 1: 6, 2: 6 } },
    { name: "Movimientos", title: "KAIRUS  /  Movimientos",
      subtitle: `Importes en ${currency} · Los comprobantes se guardan en la copia de seguridad.`,
      headers: ["Fecha", "Tipo", "Categoría", "Importe", "Cuenta", "Destino", "Nota", "Comprobante"],
      widths: [15, 18, 26, 18, 24, 24, 48, 17], rows: movements, formats: { 0: 8, 3: 6 } },
    { name: "Mensual", title: "KAIRUS  /  Mes a mes",
      subtitle: "Las transferencias internas se excluyen del total de ingresos y gastos.",
      headers: ["Mes", "Ingresos", "Gastos", "Balance", "Presupuesto", "Presupuesto restante"],
      widths: [15, 18, 18, 18, 18, 24], rows: monthly.length ? monthly : [["Sin datos", 0, 0]],
      formats: { 1: 6, 2: 6, 3: 6, 4: 6, 5: 6 } },
    { name: "Categorías", title: "KAIRUS  /  Categorías",
      subtitle: `Totales por categoría del historial completo · ${currency}`,
      headers: ["Categoría", "Tipo", "Importe"], widths: [36, 23, 24],
      rows: byCategory.length ? byCategory : [["Sin datos", "", 0]], formats: { 2: 6 } },
    { name: "Cuentas", title: "KAIRUS  /  Cuentas",
      subtitle: "Los saldos incluyen las transferencias entre cuentas.",
      headers: ["Cuenta", "Saldo inicial", "Saldo actual", "Estado"], widths: [36, 20, 20, 17],
      rows: ledger.accounts.map(a => [a.name, a.initial / 100, accountBalance(ledger, a.id) / 100,
        a.archived ? "Archivada" : "Activa"]), formats: { 1: 6, 2: 6 } },
  ];
  const override = (path, type) => `<Override PartName="/xl/${path}" ContentType="application/vnd.openxmlformats-officedocument.${type}+xml"/>`;
  const parts = {
    "[Content_Types].xml": `<Types xmlns="${pkg}/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>
    ${override("workbook.xml", "spreadsheetml.sheet.main")}${override("styles.xml", "spreadsheetml.styles")}
    ${sheets.map((_, i) => override(`worksheets/sheet${i + 1}.xml`, "spreadsheetml.worksheet")).join("")}
    ${override("drawings/drawing1.xml", "drawing")}${override("charts/chart1.xml", "drawingml.chart")}${override("charts/chart2.xml", "drawingml.chart")}</Types>`,
    "_rels/.rels": relationships([["officeDocument", "xl/workbook.xml"]]),
    "xl/workbook.xml": `<workbook xmlns="${main}" xmlns:r="${rel}"><sheets>${sheets.map(({ name }, i) =>
      `<sheet name="${name}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join("")}</sheets></workbook>`,
    "xl/_rels/workbook.xml.rels": relationships([
      ...sheets.map((_, i) => ["worksheet", `worksheets/sheet${i + 1}.xml`]), ["styles", "styles.xml"],
    ]),
    "xl/styles.xml": styles(currency),
    "xl/worksheets/_rels/sheet1.xml.rels": relationships([["drawing", "../drawings/drawing1.xml"]]),
    "xl/drawings/drawing1.xml": chartDrawing(),
    "xl/drawings/_rels/drawing1.xml.rels": relationships([["chart", "../charts/chart1.xml"], ["chart", "../charts/chart2.xml"]]),
    "xl/charts/chart1.xml": barChart({ title: `Ingresos y gastos · últimos 12 meses con datos (${currency})`,
      sheet: "Mensual", start: 5 + monthly.length - months.length, rows: months.length ? months : [["Sin datos", 0, 0]],
      series: [[1, "Ingresos", "218565"], [2, "Gastos", "DFAB12"]] }),
    "xl/charts/chart2.xml": barChart({ title: `Principales categorías de gasto (${currency})`,
      sheet: "'Categorías'", rows: top.length ? top : [["Sin datos", "", 0]], series: [[2, "Gastos", "DFAB12"]], horizontal: true }),
  };
  if (!top.length && byCategory.length) {
    // Place a chart placeholder after any income-only category rows.
    sheets[3].rows = [...byCategory, ["Sin gastos", "", 0]];
    parts["xl/charts/chart2.xml"] = barChart({ title: `Principales categorías de gasto (${currency})`,
      sheet: "'Categorías'", start: 5 + byCategory.length, rows: [["Sin gastos", "", 0]],
      series: [[2, "Gastos", "DFAB12"]], horizontal: true });
  }
  sheets.forEach((sheet, i) => { parts[`xl/worksheets/sheet${i + 1}.xml`] = worksheet(sheet); });
  return zipSync(Object.fromEntries(Object.entries(parts).map(([path, content]) => [path, strToU8(documentXml(content))])), { level: 6 });
}
