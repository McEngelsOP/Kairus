import test from "node:test";
import assert from "node:assert/strict";
import { strFromU8, strToU8, unzipSync, zipSync } from "fflate";
import { initialState, putTransaction, backup } from "../src/model.js";
import { createBackupFile, readBackupFile } from "../src/backup-file.js";
import { createWorkbook } from "../src/workbook.js";

function ledgerFixture() {
  const ledger = initialState();
  const base = { date: "2026-11-03", account: "cash", note: "" };
  ledger.accounts.push({ id: "bank", name: "Banco", initial: 0, archived: false });
  putTransaction(ledger, { ...base, id: "meal", type: "expense", category: "food",
    amount: 1255, note: "=1+1 & <almuerzo>", receipt: "data:image/png;base64,AA==" });
  putTransaction(ledger, { ...base, id: "salary", type: "income", category: "salary", amount: 10000 });
  putTransaction(ledger, { ...base, id: "transfer", type: "transfer", category: "", to: "bank", amount: 5000 });
  ledger.budgets["2026-11"] = 2000;
  return ledger;
}

test("Kairus backup preserves receipts and reads earlier backup files", () => {
  const ledger = ledgerFixture();
  assert.deepEqual(readBackupFile(createBackupFile(ledger)), ledger);
  assert.deepEqual(readBackupFile(strToU8(backup(ledger))), ledger);
});

test("backup rejects corrupt archives and unrelated documents", () => {
  assert.throws(() => readBackupFile(strToU8("PKbroken")), /copia válida/);
  assert.throws(() => readBackupFile(zipSync({ "unrelated.txt": strToU8(backup(ledgerFixture())) })), /copia válida/);
  assert.throws(() => readBackupFile(createWorkbook(ledgerFixture())), /copia válida/);
});

test("Excel includes all records and two linked charts without counting transfers in the totals", () => {
  const parts = unzipSync(createWorkbook(ledgerFixture()));
  const read = name => strFromU8(parts["xl/" + name]);
  assert.match(read("workbook.xml"), /Resumen.*Movimientos.*Mensual.*Categorías.*Cuentas/s);
  const summary = read("worksheets/sheet1.xml");
  assert.match(summary, /r="A5"[^>]*><v>100<\/v>.*r="B5"[^>]*><v>12\.55<\/v>.*r="C5"[^>]*><v>87\.45<\/v>/s);
  const entries = read("worksheets/sheet2.xml");
  assert.match(entries, /Transferencia/);
  assert.match(entries, /t="inlineStr"><is><t xml:space="preserve">=1\+1 &amp; &lt;almuerzo&gt;/);
  assert.match(read("drawings/_rels/drawing1.xml.rels"), /chart1\.xml.*chart2\.xml/s);
  assert.match(read("charts/chart1.xml"), /Mensual!\$B\$5:\$B\$5/);
  assert.match(read("charts/chart2.xml"), /'Categorías'!\$C\$5:\$C\$5/);
});

test("Excel opens without transactions and charts reference fallback cells", () => {
  const parts = unzipSync(createWorkbook(initialState()));
  assert.match(strFromU8(parts["xl/charts/chart1.xml"]), /Sin datos/);
  assert.match(strFromU8(parts["xl/charts/chart2.xml"]), /Sin datos/);
});
