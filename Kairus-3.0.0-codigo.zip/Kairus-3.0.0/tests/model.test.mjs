import test from "node:test";
import assert from "node:assert/strict";
import {
  initialState,
  parseMoney,
  calculate,
  putTransaction,
  monthly,
  accountBalance,
  categoryTotals,
  validDate,
  nextOccurrence,
  completeRecurring,
  backup,
  parseBackup,
  validateState,
  csv,
  quickEntry,
} from "../src/model.js";
function tx(s, extra = {}) {
  return putTransaction(s, {
    id: "test",
    type: "expense",
    amount: 1000,
    date: "2026-11-03",
    category: "food",
    account: "cash",
    note: "",
    ...extra,
  });
}
test("money uses exact cents with dot or comma and rejects rounding surprises", () => {
  assert.equal(parseMoney("0.10") + parseMoney("0,20"), 30);
  assert.equal(parseMoney("14,05"), 1405);
  assert.equal(parseMoney("-20.50", true), -2050);
  for (const x of ["1.234", "1,234.56", "Infinity", "NaN", "1e3", "", -1])
    assert.throws(() => parseMoney(x));
});
test("calculator precedence, parentheses and unary negatives without eval", () => {
  assert.equal(calculate("18.50 + 7.20"), "25.70");
  assert.equal(calculate("2+3×4"), "14.00");
  assert.equal(calculate("(2+3)×4"), "20.00");
  assert.equal(calculate("2 * -3 + 7"), "1.00");
  for (const x of ["alert(1)", "2/0", "4+", "1..2", "(2+3", "4**2", "99;1"])
    assert.throws(() => calculate(x));
});
test("fresh ledger is empty and valid with one account", () => {
  const s = initialState();
  assert.equal(s.transactions.length, 0);
  assert.equal(accountBalance(s, "cash"), 0);
  validateState(s);
});
test("income and expense totals include cents exactly", () => {
  const s = initialState();
  tx(s, { id: "a", amount: 10 });
  tx(s, { id: "b", amount: 20 });
  tx(s, { id: "c", type: "income", category: "salary", amount: 1000 });
  assert.deepEqual(
    [
      monthly(s, "2026-11").expense,
      monthly(s, "2026-11").income,
      monthly(s, "2026-11").balance,
    ],
    [30, 1000, 970],
  );
  assert.equal(accountBalance(s, "cash"), 970);
});
test("transfer conserves net worth and is excluded from income/expense/category charts", () => {
  const s = initialState();
  s.accounts[0].initial = 10000;
  s.accounts.push({
    id: "bank",
    name: "Banco",
    initial: -2000,
    archived: false,
  });
  tx(s, { type: "transfer", category: "", to: "bank", amount: 3500 });
  assert.equal(accountBalance(s, "cash"), 6500);
  assert.equal(accountBalance(s, "bank"), 1500);
  assert.equal(monthly(s, "2026-11").expense, 0);
  assert.equal(monthly(s, "2026-11").income, 0);
  assert.equal(categoryTotals(s, "2026-11").length, 0);
  assert.equal(accountBalance(s, "cash") + accountBalance(s, "bank"), 8000);
});
test("same-account, missing-account, wrong-category and non-positive values cannot save", () => {
  for (const patch of [
    { type: "transfer", category: "", to: "cash" },
    { account: "missing" },
    { category: "salary" },
    { amount: 0 },
    { amount: -1 },
    { amount: 0.1 },
  ])
    assert.throws(() => tx(initialState(), patch));
});
test("editing an entry updates balances once and deletion reverses it", () => {
  const s = initialState();
  tx(s);
  tx(s, { amount: 2250 });
  assert.equal(s.transactions.length, 1);
  assert.equal(accountBalance(s, "cash"), -2250);
  s.transactions = [];
  assert.equal(accountBalance(s, "cash"), 0);
});
test("calendar date validation handles leap years and impossible days", () => {
  assert.ok(validDate("2024-02-29"));
  for (const d of [
    "2026-02-29",
    "2026-04-31",
    "2026-13-01",
    "2026-00-01",
    "2026-1-2",
    "0000-01-01",
  ])
    assert.equal(validDate(d), false);
});
test("monthly recurrence clamps February then restores original day", () => {
  const feb = nextOccurrence("2026-01-31", "monthly", 31);
  assert.equal(feb, "2026-02-28");
  assert.equal(nextOccurrence(feb, "monthly", 31), "2026-03-31");
  assert.equal(nextOccurrence("2024-02-29", "yearly", 29), "2025-02-28");
  assert.equal(nextOccurrence("2026-12-29", "weekly"), "2027-01-05");
});
test("recurring entry commits only due occurrence; skip does not add a transaction", () => {
  const s = initialState();
  const item = tx(s, { date: "2020-01-31" });
  s.recurring.push({
    ...item,
    id: "schedule",
    nextDate: "2020-02-29",
    frequency: "monthly",
    day: 31,
    active: true,
  });
  completeRecurring(s, "schedule");
  assert.equal(s.transactions.length, 2);
  assert.equal(s.recurring[0].nextDate, "2020-03-31");
  completeRecurring(s, "schedule", true);
  assert.equal(s.transactions.length, 2);
  assert.equal(s.recurring[0].nextDate, "2020-04-30");
});
test("future recurrence cannot be recorded early", () => {
  const s = initialState();
  const item = tx(s);
  s.recurring.push({
    ...item,
    id: "schedule",
    nextDate: "2199-01-01",
    frequency: "monthly",
    day: 1,
    active: true,
  });
  assert.throws(() => completeRecurring(s, "schedule"));
});
test("monthly reporting isolates year and excludes other periods", () => {
  const s = initialState();
  tx(s, { id: "a" });
  tx(s, { id: "b", date: "2025-11-03" });
  tx(s, { id: "c", date: "2026-12-03" });
  assert.equal(monthly(s, "2026-11").expense, 1000);
});
test("category report sorts actual totals", () => {
  const s = initialState();
  tx(s);
  tx(s, { id: "b", category: "transport", amount: 2500 });
  assert.deepEqual(
    categoryTotals(s, "2026-11").map((x) => [x.id, x.amount]),
    [
      ["transport", 2500],
      ["food", 1000],
    ],
  );
});
test("backup restores all ledger data and receipts", () => {
  const s = initialState();
  tx(s, { receipt: "data:image/jpeg;base64,AAAA" });
  s.budgets["2026-11"] = 50000;
  assert.deepEqual(parseBackup(backup(s)), s);
});
test("backup rejects duplicate IDs, invalid currency and broken references", () => {
  for (const mutate of [
    (s) => s.transactions.push({ ...s.transactions[0] }),
    (s) => (s.settings.currency = "XYZ"),
    (s) => (s.transactions[0].account = "unknown"),
    (s) => (s.transactions[0].category = "salary"),
    (s) => (s.accounts = []),
    (s) => (s.transactions[0].receipt = "data:text/html;base64,AAAA"),
    (s) => (s.categories[0].color = "red;position:fixed"),
    (s) => (s.budgets["2026-99"] = -1),
    (s) => (s.version = 200),
  ]) {
    const s = initialState();
    tx(s);
    mutate(s);
    assert.throws(() => parseBackup(backup(s)));
  }
});
test("backup rejects non-Kairus documents and corrupted JSON", () => {
  for (const raw of ["{}", "{", '{"app":"Other"}', "[]"])
    assert.throws(() => parseBackup(raw));
});
test("CSV neutralizes spreadsheet formula injection and escapes quotes and newlines", () => {
  const s = initialState();
  tx(s, { note: '=HYPERLINK("bad")\nnext' });
  const out = csv(s);
  assert.ok(out.startsWith("\uFEFF"));
  assert.ok(out.includes('"\'=HYPERLINK(""bad"")\nnext"'));
});
test("quick entry proposes an expense or income but never mutates state", () => {
  const s = initialState();
  assert.equal(quickEntry(s, "gasté 18,50 en alimentación").amount, 1850);
  assert.equal(quickEntry(s, "gasté 5 en taxi").category, "transport");
  assert.equal(quickEntry(s, "recibí 500 de sueldo").type, "income");
  assert.equal(s.transactions.length, 0);
  assert.throws(() => quickEntry(s, "sin cantidad"));
});
test("archived account balances remain in the ledger", () => {
  const s = initialState();
  s.accounts.push({ id: "bank", name: "Banco", initial: 1000, archived: true });
  assert.equal(accountBalance(s, "bank"), 1000);
  validateState(s);
});
test("financial totals remain safe integers for large records", () => {
  const s = initialState();
  for (let i = 0; i < 1000; i++) tx(s, { id: "t" + i, amount: 9999999999 });
  assert.equal(monthly(s, "2026-11").expense, 9999999999000);
  assert.ok(Number.isSafeInteger(accountBalance(s, "cash")));
});
