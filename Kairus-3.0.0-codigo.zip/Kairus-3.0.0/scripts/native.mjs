import { existsSync } from "node:fs";
import {
  readFile,
  writeFile,
  mkdir,
  copyFile,
  readdir,
} from "node:fs/promises";
import { spawnSync } from "node:child_process";
const platform = process.argv[2];
if (!["android", "ios"].includes(platform))
  throw new Error("Use android or ios");
function cap(args) {
  const r = spawnSync(
    process.execPath,
    ["node_modules/@capacitor/cli/bin/capacitor", ...args],
    { stdio: "inherit" },
  );
  if (r.status !== 0) process.exit(r.status || 1);
}
if (!existsSync(platform)) cap(["add", platform]);
cap(["sync", platform]);
if (platform === "android") {
  const path = "android/app/src/main/AndroidManifest.xml";
  let xml = await readFile(path, "utf8");
  xml = xml.replace(
    'android:allowBackup="true"',
    'android:allowBackup="false"',
  );
  if (!xml.includes("POST_NOTIFICATIONS"))
    xml = xml.replace(
      "</manifest>",
      '    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n</manifest>',
    );
  await writeFile(path, xml);
  const colors = "android/app/src/main/res/values/ic_launcher_background.xml";
  await writeFile(
    colors,
    '<?xml version="1.0" encoding="utf-8"?><resources><color name="ic_launcher_background">#1a1a1a</color></resources>\n',
  );
  for (const folder of [
    "mipmap-mdpi",
    "mipmap-hdpi",
    "mipmap-xhdpi",
    "mipmap-xxhdpi",
    "mipmap-xxxhdpi",
  ]) {
    await mkdir(`android/app/src/main/res/${folder}`, { recursive: true });
    for (const name of [
      "ic_launcher.png",
      "ic_launcher_round.png",
      "ic_launcher_foreground.png",
    ])
      await copyFile(
        name === "ic_launcher_foreground.png" ? "public/icons/icon-adaptive.png" : "public/icons/icon-512.png",
        `android/app/src/main/res/${folder}/${name}`,
      );
  }
  for (const folder of await readdir("android/app/src/main/res"))
    if (existsSync(`android/app/src/main/res/${folder}/splash.png`))
      await copyFile(
        "resources/splash.png",
        `android/app/src/main/res/${folder}/splash.png`,
      );
  const adaptive = "android/app/src/main/res/mipmap-anydpi-v26";
  for (const file of ["ic_launcher.xml", "ic_launcher_round.xml"])
    await writeFile(
      `${adaptive}/${file}`,
      '<?xml version="1.0" encoding="utf-8"?><adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android"><background android:drawable="@color/ic_launcher_background"/><foreground android:drawable="@mipmap/ic_launcher_foreground"/></adaptive-icon>\n',
    );
  console.log(
    "Android listo. Generar APK: cd android && ./gradlew assembleDebug",
  );
} else {
  const path = "ios/App/App/Info.plist";
  let xml = await readFile(path, "utf8");
  xml = xml.replace(
    /<key>NS(?:PhotoLibrary|Camera)UsageDescription<\/key>\s*<string>[^<]*<\/string>/g,
    "",
  );
  xml = xml.replace(
    /<\/dict>\s*<\/plist>\s*$/,
    "<key>NSPhotoLibraryUsageDescription</key><string>Adjuntar un comprobante a un movimiento.</string>\n<key>NSCameraUsageDescription</key><string>Fotografiar un comprobante para tu registro personal.</string>\n</dict>\n</plist>\n",
  );
  await writeFile(path, xml);
  await mkdir("ios/App/App/Assets.xcassets/AppIcon.appiconset", {
    recursive: true,
  });
  await copyFile(
    "public/icons/icon-1024.png",
    "ios/App/App/Assets.xcassets/AppIcon.appiconset/AppIcon-512@2x.png",
  );
  await writeFile(
    "ios/App/App/Assets.xcassets/AppIcon.appiconset/Contents.json",
    JSON.stringify(
      {
        images: [
          {
            filename: "AppIcon-512@2x.png",
            idiom: "universal",
            platform: "ios",
            size: "1024x1024",
          },
        ],
        info: { author: "xcode", version: 1 },
      },
      null,
      2,
    ),
  );
  await copyFile(
    "docs/PrivacyInfo.xcprivacy",
    "ios/App/App/PrivacyInfo.xcprivacy",
  );
  const project = "ios/App/App.xcodeproj/project.pbxproj";
  let pbx = await readFile(project, "utf8");
  if (!pbx.includes("PrivacyInfo.xcprivacy")) {
    pbx = pbx.replace(
      "/* Begin PBXBuildFile section */",
      "/* Begin PBXBuildFile section */\n\t\tA11A11A11A11A11A11A11A11 /* PrivacyInfo.xcprivacy in Resources */ = {isa = PBXBuildFile; fileRef = B22B22B22B22B22B22B22B22 /* PrivacyInfo.xcprivacy */; };",
    );
    pbx = pbx.replace(
      "/* Begin PBXFileReference section */",
      '/* Begin PBXFileReference section */\n\t\tB22B22B22B22B22B22B22B22 /* PrivacyInfo.xcprivacy */ = {isa = PBXFileReference; lastKnownFileType = text.xml; path = PrivacyInfo.xcprivacy; sourceTree = "<group>"; };',
    );
    pbx = pbx.replace(
      "504EC3071FED79650016851F /* AppDelegate.swift */,",
      "504EC3071FED79650016851F /* AppDelegate.swift */,\n\t\t\t\tB22B22B22B22B22B22B22B22 /* PrivacyInfo.xcprivacy */,",
    );
    pbx = pbx.replace(
      "504EC3121FED79650016851F /* LaunchScreen.storyboard in Resources */,",
      "504EC3121FED79650016851F /* LaunchScreen.storyboard in Resources */,\n\t\t\t\tA11A11A11A11A11A11A11A11 /* PrivacyInfo.xcprivacy in Resources */,",
    );
    await writeFile(project, pbx);
  }
  console.log(
    "iOS listo. Abre Xcode y selecciona tu equipo de firma: npx cap open ios",
  );
}
