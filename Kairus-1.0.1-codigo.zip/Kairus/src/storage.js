import { Capacitor } from "@capacitor/core";
import { Preferences } from "@capacitor/preferences";
import { initialState, validateState, uid } from "./model.js";

const KEY = "kairus-ledger-v1";
export const native = Capacitor.isNativePlatform();
let dbPromise;
let browserBackend;
function database() {
  if (!dbPromise)
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open("kairus", 1);
      req.onupgradeneeded = () => req.result.createObjectStore("records");
      req.onerror = () =>
        reject(
          new Error(
            "No se pudo abrir el almacenamiento. Revisa el espacio y los permisos del navegador.",
          ),
        );
      req.onsuccess = () => resolve(req.result);
    });
  return dbPromise;
}
function storageBackend() {
  if (!browserBackend)
    browserBackend = database().catch((error) => {
      if (location.protocol !== "file:") throw error;
      // Some browsers restrict IndexedDB for files opened from disk.
      localStorage.getItem(KEY);
      return null;
    });
  return browserBackend;
}
export async function readRaw() {
  if (native) return (await Preferences.get({ key: KEY })).value;
  const db = await storageBackend();
  if (!db) return localStorage.getItem(KEY);
  return new Promise((resolve, reject) => {
    const req = db.transaction("records").objectStore("records").get(KEY);
    req.onsuccess = () => resolve(req.result ?? null);
    req.onerror = () => reject(req.error);
  });
}
export async function load(raw = undefined) {
  if (raw === undefined) raw = await readRaw();
  if (raw == null) return initialState();
  try {
    return validateState(typeof raw === "string" ? JSON.parse(raw) : raw);
  } catch {
    throw new Error(
      "No se pudo leer tu registro. Tus datos siguen guardados; descarga una copia de recuperación antes de restaurar otro archivo.",
    );
  }
}
export async function persist(next, previousRevision) {
  validateState(next);
  next.revision = previousRevision + 1;
  const value = JSON.stringify(next);
  if (native) {
    const previous = await readRaw();
    if (previous && JSON.parse(previous).revision !== previousRevision)
      throw new Error("El registro cambió en otra ventana. Vuelve a intentar.");
    await Preferences.set({ key: KEY, value });
    return;
  }
  const db = await storageBackend();
  if (!db) {
    const previous = localStorage.getItem(KEY);
    if (previous && JSON.parse(previous).revision !== previousRevision)
      throw new Error("El registro cambió en otra ventana. Vuelve a intentar.");
    localStorage.setItem(KEY, value);
    return;
  }
  await new Promise((resolve, reject) => {
    const tx = db.transaction("records", "readwrite"),
      store = tx.objectStore("records"),
      req = store.get(KEY);
    let error;
    req.onsuccess = () => {
      const previous = req.result ? JSON.parse(req.result) : null;
      if (previous && previous.revision !== previousRevision) {
        error = new Error(
          "El registro cambió en otra ventana. Vuelve a intentar.",
        );
        tx.abort();
        return;
      }
      store.put(value, KEY);
    };
    tx.oncomplete = resolve;
    tx.onabort = tx.onerror = () =>
      reject(
        error ||
          new Error(
            "No se pudo guardar. Revisa el espacio disponible; conserva una copia de seguridad.",
          ),
      );
  });
}

export async function saveFile(name, content, mime = "application/json") {
  if (native) {
    const [{ Filesystem, Directory, Encoding }, { Share }] = await Promise.all([
      import("@capacitor/filesystem"),
      import("@capacitor/share"),
    ]);
    const { uri } = await Filesystem.writeFile({
      path: name,
      data: content,
      directory: Directory.Cache,
      encoding: Encoding.UTF8,
    });
    await Share.share({
      title: "Kairus",
      url: uri,
      dialogTitle: "Guardar o compartir copia",
    });
    return;
  }
  const url = URL.createObjectURL(new Blob([content], { type: mime }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}

export async function scheduleReminder(time, language = "es") {
  if (!native) return;
  const { LocalNotifications } = await import("@capacitor/local-notifications");
  if (time) {
    const permission = await LocalNotifications.requestPermissions();
    if (permission.display !== "granted")
      throw new Error(
        "Activa las notificaciones de Kairus en los ajustes del teléfono.",
      );
  }
  await LocalNotifications.cancel({ notifications: [{ id: 101 }] });
  if (time) {
    const [hour, minute] = time.split(":").map(Number);
    await LocalNotifications.schedule({
      notifications: [
        {
          id: 101,
          title: "Kairus",
          body:
            language === "es"
              ? "Un minuto para poner tus gastos al día."
              : "A minute to catch up on your spending.",
          schedule: { on: { hour, minute }, repeats: true },
        },
      ],
    });
  }
}
export function reminderCalendar(time) {
  const date = new Date();
  const [h, m] = time.split(":").map(Number);
  date.setHours(h, m, 0, 0);
  if (date < new Date()) date.setDate(date.getDate() + 1);
  const pad = (n) => String(n).padStart(2, "0");
  const local = `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}T${pad(h)}${pad(m)}00`;
  return [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Kairus//Recordatorio//ES",
    "BEGIN:VEVENT",
    `UID:${uid()}@kairus`,
    `DTSTAMP:${new Date()
      .toISOString()
      .replace(/[-:]/g, "")
      .replace(/\.\d{3}/, "")}`,
    `DTSTART:${local}`,
    "DURATION:PT5M",
    "RRULE:FREQ=DAILY",
    "SUMMARY:Registrar mis gastos en Kairus",
    "BEGIN:VALARM",
    "TRIGGER:PT0M",
    "ACTION:DISPLAY",
    "DESCRIPTION:Registrar mis gastos en Kairus",
    "END:VALARM",
    "END:VEVENT",
    "END:VCALENDAR",
    "",
  ].join("\r\n");
}
