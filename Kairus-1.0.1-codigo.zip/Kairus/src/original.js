import './original.css';
import './local-panels.css';
import { Capacitor } from '@capacitor/core';
import { App } from '@capacitor/app';
import { initialState, uid, today, localDate, parseMoney, calculate, validDate, putTransaction, monthly, accountBalance, nextOccurrence, completeRecurring, csv, backup, parseBackup } from './model.js';
import { load, readRaw, persist, saveFile, scheduleReminder, reminderCalendar } from './storage.js';
import { escapeHTML } from './escape.js';

const $=s=>document.querySelector(s),pad=n=>String(n).padStart(2,'0');
const RM=matchMedia('(prefers-reduced-motion:reduce)').matches;
const MONTHS=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

/* Iconos y categorías: agrega nuevas aquí */
const I={
  food:'<path d="M7 3v6a2 2 0 0 0 4 0V3M9 3v18M17 21V3c-2.5 1.5-3.5 4.5-3.5 8H17"/>',
  edu:'<path d="M6 4h11a1 1 0 0 1 1 1v15H8a2 2 0 0 1-2-2V4zM6 18a2 2 0 0 1 2-2h10M10 8h4"/>',
  trans:'<rect x="5" y="3" width="14" height="15" rx="3"/><path d="M5 12h14M8 21v-3M16 21v-3M9 15h.01M15 15h.01"/>',
  salary:'<rect x="3" y="6" width="18" height="13" rx="2.5"/><path d="M3 10h18"/><circle cx="12" cy="14.5" r="1.6"/>'
};
const CATS={
  food:{n:'Food',a:'#2fd39b',b:'#c2f4df'},
  edu:{n:'Education',a:'#ff8a3d',b:'#ffcfae'},
  trans:{n:'Transportation',a:'#d99d97',b:'#f0d6d3'},
  salary:{n:'Salary',a:'#f2c94c',b:'#fbeab5'}
};

/* Datos: [fecha, categoría, monto]. Negativo = gasto, positivo = ingreso */
const TX=[];

const NOW=new Date(),TY=NOW.getFullYear(),TM=NOW.getMonth();
let year=TY,month=TM,q='',shown={e:0,i:0,b:0,c:0,ce:0,ci:0,cb:0};
const L=$('#list'),r2=n=>Math.round(n*100)/100,f2=n=>n.toFixed(2);
const money=n=>(n<0?'-':'')+cs()+(Number.isInteger(n)?Math.abs(n):Math.abs(n).toFixed(2));
const sumOf=(arr,f)=>arr.filter(f).reduce((x,t)=>x+t.amount,0)/100;

function tween(el,k,to){
  const from=shown[k],t0=performance.now(),D=RM?0:900;shown[k]=to;el._t=t0;
  const step=t=>{if(el._t!==t0)return;const p=D?Math.min((t-t0)/D,1):1;
    el.textContent=cs()+f2(from+(to-from)*(1-Math.pow(1-p,4)));if(p<1)requestAnimationFrame(step)};
  requestAnimationFrame(step);
}

function render(anim=true){
  const mt=TX.filter(t=>t.d.startsWith(`${year}-${pad(month+1)}`));
  const E=sumOf(mt,t=>t.a<0),In=sumOf(mt,t=>t.a>0);
  tween($('#ne'),'e',E);tween($('#ni'),'i',In);tween($('#nb'),'b',r2(In-E));rep(E,In);

  const s=q.trim().toLowerCase();
  const items=mt.filter(t=>!s||[CATS[t.c].n,t.n,String(t.amount/100)].some(value=>value.toLowerCase().includes(s)));
  let i=0,h='';
  [...new Set(items.map(t=>t.d))].sort().reverse().forEach(d=>{
    const g=items.filter(t=>t.d===d),e=sumOf(g,t=>t.a<0),inc=sumOf(g,t=>t.a>0),dt=new Date(d+'T00:00');
    h+=`<div class="day" style="--i:${Math.min(i++,14)}"><span>${MONTHS[dt.getMonth()]} ${dt.getDate()}<i>${dt.toLocaleDateString(LOC,{weekday:'long'})}</i></span><span>${e?`${_('Expenses')}: ${cs()+f2(e)}`:''}${inc?`<em>${_('Income')}: ${cs()+f2(inc)}</em>`:''}</span></div>`;
    g.forEach(t=>{const c=CATS[t.c];
      h+=transactionRow(t,Math.min(i++,14));});
  });
  if(!h)h=`<div class="empty"><svg viewBox="0 0 24 24">${I.salary}</svg><b>${_(s?'No results':'No transactions yet')}</b><span>${s?_('Try another category or amount'):_('Nothing recorded in')+' '+MONTHS[month]+' '+year}</span></div>`;
  L.className='list'+(anim?' anim':'');L.innerHTML=h;
}

function go(y,m){
  year=y;month=m;$('#pyr').textContent=y;$('#pm').textContent=MONTHS[m];
  L.classList.add('out');
  setTimeout(()=>{L.scrollTop=0;render(true)},RM?0:180);
}

/* Selector de mes */
let py=year;
function grid(){
  $('#yl').textContent=py;
  $('#months').innerHTML=MONTHS.map((n,i)=>`<button class="m${py===CY()&&i===CM()?' on':''}${tgt==='charts'&&(py>TY||py===TY&&i>TM)?' dis':''}${TX.some(t=>t.d.startsWith(py+'-'+pad(i+1)))?' has':''}" style="--i:${i}" data-m="${i}">${n}</button>`).join('');
}
function sheet(o){if(o){py=CY();grid()}$('#app').classList.toggle('open',o);$('#pill').classList.toggle('open',o)}
$('#pill').onclick=()=>{tgt='home';sheet(true)};
$('#cal').onclick=()=>calOpen();
$('#bd').onclick=()=>sheet(false);
$('#yp').onclick=()=>{py--;grid()};
$('#yn').onclick=()=>{if(tgt==='charts'&&py>=TY)return;py++;grid()};
$('#months').onclick=e=>{const b=e.target.closest('.m');if(!b||b.classList.contains('dis'))return;sheet(false);calOn?calGo(py,+b.dataset.m):(tgt==='charts'?chGo:go)(py,+b.dataset.m)};

addEventListener('keydown',e=>{if(e.key==='Escape'){if($('#ax').classList.contains('on'))return closeAI();sheet(false);if($('#add').classList.contains('aopen'))$('#add').classList.remove('aopen');else setAdd(false)}});

/* Pestañas + barra flotante */
const V=['home','charts','reports','profile'],tabs=[...document.querySelectorAll('.tab')];
function show(i){
  tabs.forEach((t,j)=>t.classList.toggle('on',j===i));
  $('#ind').style.setProperty('--i',i);
  const p=$('#slide');p.classList.remove('go');void p.offsetWidth;p.classList.add('go');
  V.forEach((n,j)=>{const v=$('#v-'+n);v.classList.toggle('on',j===i);v.classList.toggle('left',j<i)});
  sheet(false);
  if(i===1)chShow();
}
tabs.forEach((b,i)=>b.onclick=()=>show(i));
/* Pantalla Add: se abre desde el botón + */
const A={
haircut:'<circle cx="7" cy="17" r="2.5"/><circle cx="17" cy="17" r="2.5"/><path d="M8.5 15 17 4M15.5 15 7 4"/>',
shopping:'<path d="M3 4h2l2.5 11h10L20 8H6.5"/><circle cx="9" cy="19" r="1.3"/><circle cx="17" cy="19" r="1.3"/>',
phone:'<rect x="7" y="3" width="10" height="18" rx="2"/><path d="M11 18h2"/>',
fun:'<rect x="9" y="3" width="6" height="10" rx="3"/><path d="M6 11a6 6 0 0 0 12 0M12 17v4"/>',
beauty:'<circle cx="12" cy="9" r="5"/><path d="M5 21c0-4 3-6 7-6s7 2 7 6M9 8c2 0 4-1 5-3"/>',
sports:'<circle cx="17" cy="6" r="2"/><path d="M3 14c2-1.5 3 1.5 5 0s3 1.5 5 0 3 1.5 5 0 2 .5 3 0M3 19c2-1.5 3 1.5 5 0s3 1.5 5 0 3 1.5 5 0"/>',
social:'<circle cx="9" cy="9" r="3"/><circle cx="17" cy="10" r="2.4"/><path d="M3 20c0-3.5 2.7-5.5 6-5.5s6 2 6 5.5M15.5 14.8c3 0 5.5 1.7 5.5 5"/>',
cloth:'<path d="M8 3 6 8c0 2 1 3 2 3v10h8V11c1 0 2-1 2-3l-2-5M8 3c0 2 1.5 3 4 3s4-1 4-3"/>',
car:'<path d="M4 15v-3l2-4.5h12L20 12v3zM4 15v3h3v-3M17 15v3h3v-3"/>',
alcohol:'<path d="M7 3h3v4l1 2v12H6V9l1-2zM15 12h5l-1 4a2 2 0 0 1-3 0zM17.5 16v5M15 21h5"/>',
cig:'<rect x="6" y="4" width="12" height="17" rx="1.5"/><path d="M6 9h12M10 12v5M13 12v5"/>',
elec:'<rect x="5" y="3" width="11" height="18" rx="2"/><circle cx="10.5" cy="14" r="3"/><rect x="8" y="6" width="5" height="3"/>',
plane:'<path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z"/>',
health:'<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V5h6v2M12 10.5v6M9 13.5h6"/>',
pets:'<path d="M5 6 8 9h8l3-3v8a7 7 0 0 1-14 0z"/><path d="M10.5 16h3M9.5 13h.01M14.5 13h.01"/>',
repair:'<path d="M14.5 6.5a4 4 0 0 0 5 5L10 21l-3-3z"/><path d="M5 4l5 5"/>',
roller:'<rect x="4" y="3" width="14" height="5" rx="1"/><path d="M18 5h2v5h-8v3M11 13v8"/>',
cabinet:'<rect x="4" y="3" width="16" height="18" rx="1"/><path d="M12 3v18M4 12h16M9.5 15v2M14.5 15v2"/>',
gift:'<rect x="4" y="9" width="16" height="11" rx="1"/><path d="M3 9h18M12 9v11M12 9C10 5 6 6 7.5 8.5M12 9c2-4 6-3 4.5-.5"/>',
heart:'<path d="M12 14c-4-2.5-5-4.5-5-6.5a2.8 2.8 0 0 1 5-1.5 2.8 2.8 0 0 1 5 1.5c0 2-1 4-5 6.5zM12 14l-1 3 2 2-1 3"/>',
ball:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3.5"/><path d="M12 10.5v3"/>',
muffin:'<path d="M6 12h12l-1.5 8h-9zM6.5 12a5.5 5 0 0 1 11 0M10 15v3M14 15v3"/>',
kid:'<circle cx="12" cy="7" r="3.5"/><path d="M12 11v4M5 14l7 2 7-2-2 6H7z"/>',
carrot:'<path d="M17 7 6 20c-1 1-2-1-1.5-2L15 7zM15 7l3-3M17 8l3 1M14 6l-.5-3.5"/>',
grapes:'<circle cx="9" cy="10" r="2"/><circle cx="15" cy="10" r="2"/><circle cx="12" cy="14" r="2"/><circle cx="9" cy="18" r="2"/><circle cx="15" cy="18" r="2"/><path d="M12 8V3l3 1"/>',
plus:'<path d="M12 5v14M5 12h14"/>',
bag:'<path d="M9 3h6l-1.5 3h-3zM9.5 6C6 8 4 11 4 15a5 5 0 0 0 5 5h6a5 5 0 0 0 5-5c0-4-2-7-5.5-9M12 11v6"/>',
clock:'<circle cx="12" cy="13" r="8"/><path d="M12 8v5l3 2M10 2h4"/>',
others:'<circle cx="12" cy="12" r="3"/><path d="M4 4l4 4M20 4l-4 4M4 20l4-4M20 20l-4-4"/>',
...I
};
const XC=[['Haircut','haircut'],['Shopping','shopping'],['Food','food'],['Phone','phone'],['Entertainment','fun'],['Education','edu'],['Beauty','beauty'],['Sports','sports'],['Social','social'],['Transportation','trans'],['Clothing','cloth'],['Car','car'],['Alcohol','alcohol'],['Cigarettes','cig'],['Electronics','elec'],['Travel','plane'],['Health','health'],['Pets','pets'],['Repairs','repair'],['Housing','roller'],['Home','cabinet'],['Gifts','gift'],['Donations','heart'],['Lottery','ball'],['Snacks','muffin'],['Kids','kid'],['Vegetables','carrot'],['Fruits','grapes'],['','plus']];
const IN=[['Salary','salary'],['Investments','bag'],['Part-Time','clock'],['Bonus','bonus'],['Others','others'],['Settings','plus']];
const tile=(x,i)=>`<button class="ct" style="--i:${i}" data-k="${x[1]}" data-n="${x[0]||'New category'}"><span class="c"><svg viewBox="0 0 24 24">${A[x[1]]}</svg></span>${x[0]}</button>`;
$('#pe').innerHTML=XC.map(tile).join('');$('#pi').innerHTML=IN.map(tile).join('');
const PN=['pe','pi','pt'],SB=[...document.querySelectorAll('#seg button')];
function segSet(i){clearSel();curSeg=i;
  $('#seg').style.setProperty('--s',i);
  SB.forEach((b,j)=>b.classList.toggle('on',j===i));
  PN.forEach((id,j)=>{const e=$('#'+id);e.classList.remove('on');e.classList.toggle('left',j<i);e.scrollTop=0;if(j===i){void e.offsetWidth;e.classList.add('on')}});
}
SB.forEach((b,i)=>b.onclick=()=>segSet(i));
function setAdd(o){const a=$('#add');if(o){segSet(0);sheet(false)}a.classList.toggle('on',o);$('#app').classList.toggle('addon',o);$('#fab').setAttribute('aria-expanded',String(o));$('#fab').setAttribute('aria-label',_(o?'Cerrar':'Añadir'));a.inert=!o;$('#tabs').inert=o;if(!o)a.classList.remove('aopen','sel')}
$('#fab').onclick=()=>$('#add').classList.contains('on')?setAdd(false):openAdd(null);
$('#cx').onclick=()=>setAdd(false);
$('#xa').onclick=$('#accb').onclick=()=>$('#add').classList.remove('aopen');

/* Teclado: seleccionar categoría, calcular y guardar */
A.bonus=A.gift;
const PAL=[['#6ab7ff','#cfe6ff'],['#b58cff','#e3d3ff'],['#ff7fa8','#ffd0df'],['#5fe0d0','#c8f6f0'],['#f2c94c','#fbeab5'],['#ff9f6b','#ffd9c2']];
[...XC,...IN].forEach(([n,k],i)=>{if(k!=='plus'&&!CATS[k])CATS[k]={n,a:PAL[i%6][0],b:PAL[i%6][1]}});
document.querySelectorAll('.ct').forEach(b=>{const c=CATS[b.dataset.k];if(c){b.style.setProperty('--a',c.a);b.style.setProperty('--b',c.b);b.classList.add('cl')}});
let cat=null,curSeg=0,ex='0';
const OPS='+−×÷',lastNum=()=>ex.split(/[+−×÷]/).pop();
const KS=[['7'],['8'],['9'],['t'],['4'],['5'],['6'],['+',1],['−',1],['1'],['2'],['3'],['×',1],['÷',1],['.'],['0'],['d'],['ok']];
const KI={t:'<svg viewBox="0 0 24 24"><rect x="4" y="5" width="16" height="15" rx="2"/><path d="M8 3v4M16 3v4M4 10h16"/></svg>Today',d:'<svg viewBox="0 0 24 24"><path d="M9 5h11a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H9l-6-7z"/><path d="m12 9 5 6m0-6-5 6"/></svg>',ok:'<svg viewBox="0 0 24 24"><path d="m5 12 5 5 9-10"/></svg>'};
$('#keys').innerHTML=KS.map(([k,h])=>`<button class="k${h?' h':''}${k==='ok'?' ok':''}${k==='t'?' td':''}" data-k="${k}">${KI[k]||k}</button>`).join('');
function show$(){const a=$('#amt');a.textContent=ex;a.classList.remove('b');void a.offsetWidth;a.classList.add('b')}
function keyp(k){
  if(k==='d')ex=ex.length>1?ex.slice(0,-1):'0';
  else if(OPS.includes(k))ex=OPS.includes(ex.slice(-1))?ex.slice(0,-1)+k:ex+k;
  else if(k==='.'){if(!lastNum().includes('.'))ex+=OPS.includes(ex.slice(-1))?'0.':'.'}
  else ex=ex==='0'?k:lastNum()==='0'?ex.slice(0,-1)+k:ex+k;
  show$();
}
function calc(){return parseMoney(calculate(ex));}
function clearSel(){cat=null;ex='0';$('#amt').textContent='0';$('#nt').value='';$('#add').classList.remove('sel');document.querySelectorAll('.ct.on').forEach(e=>e.classList.remove('on'))}
function pick(b){
  if(b.dataset.k==='plus')return openNc();
  cat=b.dataset.k;
  document.querySelectorAll('.ct.on').forEach(e=>e.classList.remove('on'));b.classList.add('on');
  const a=$('#add');a.style.setProperty('--kh',$('#kp').offsetHeight+'px');a.classList.add('sel');
  setTimeout(()=>b.scrollIntoView({block:'nearest',behavior:'smooth'}),120);
}

document.querySelectorAll('.ct').forEach(b=>b.onclick=()=>pick(b));
$('#acb').onclick=()=>$('#add').classList.add('aopen');

/* Toast + botones pendientes */
let tt;
function toast(m){const t=$('#toast');t.textContent=_t(m);t.classList.add('on');clearTimeout(tt);tt=setTimeout(()=>t.classList.remove('on'),1800)}

/* =====================================================
   CALENDARIO
   Cuadrícula mensual con totales por día. Se abre con el icono
   de calendario (onda desde el icono), se arrastra a los lados
   para cambiar de mes y el selector de día se desliza con resorte.
   ===================================================== */
const CL=$('#cl'),CW=$('#clw'),EASE='cubic-bezier(.22,1,.36,1)';
let calOn=false,cg=null,selD=1,pend=null,dr=null,dragged=false,dt,addDate=null;
const dkey=(y,m,d)=>`${y}-${pad(m+1)}-${pad(d)}`;
const kfmt=n=>n>=1000?(n/1000).toFixed(1)+'k':f2(n);
const rowsOf=(y,m)=>Math.ceil((new Date(y,m,1).getDay()+new Date(y,m+1,0).getDate())/7);
const nbOf=dir=>{let y=year,m=month+dir;if(m<0){m=11;y--}if(m>11){m=0;y++}return[y,m]};
$('#cldw').innerHTML=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map((d,i)=>`<span style="--i:${i}">${d}</span>`).join('');

/* Día que queda seleccionado al entrar a un mes: hoy, o el último con movimientos */
function defDay(y,m){
  const n=new Date();
  if(y===n.getFullYear()&&m===n.getMonth())return n.getDate();
  const k=TX.filter(t=>t.d.startsWith(`${y}-${pad(m+1)}`)).map(t=>+t.d.slice(8,10)).sort((a,b)=>a-b);
  return k.length?k[k.length-1]:1;
}

function buildGrid(y,m){
  const g=document.createElement('div');g.className='clg';
  const first=new Date(y,m,1).getDay(),dim=new Date(y,m+1,0).getDate(),n=new Date(),by={};
  TX.forEach(t=>{if(t.d.startsWith(`${y}-${pad(m+1)}`)){const d=+t.d.slice(8,10);(by[d]=by[d]||[]).push(t)}});
  let h='';
  for(let i=0;i<first;i++)h+='<span></span>';
  for(let d=1;d<=dim;d++){
    const l=by[d]||[],e=sumOf(l,t=>t.a<0),inc=sumOf(l,t=>t.a>0),idx=first+d-1;
    const tod=y===n.getFullYear()&&m===n.getMonth()&&d===n.getDate();
    const lab=`${MONTHS[m]} ${d}${tod?', today':''}${inc?`, income ${f2(inc)}`:''}${e?`, expenses ${f2(e)}`:''}`;
    h+=`<button class="cld${l.length?(inc-e>=0?' p':' n'):''}${tod?' t':''}" data-d="${d}" aria-label="${lab}" style="--c:${idx%7};--r:${(idx/7)|0}"><span class="cln">${d}</span>${inc?`<span class="cla i">+${kfmt(inc)}</span>`:''}${e?`<span class="cla e">−${kfmt(e)}</span>`:''}</button>`;
  }
  g.innerHTML=h+'<i class="clk"></i>';
  return g;
}

/* Marco de selección: se desliza (con resorte) hasta el día elegido */
function ring(g,d,instant){
  const c=g.querySelector(`.cld[data-d="${d}"]`),k=g.querySelector('.clk');
  if(!c||!k)return;
  if(instant)k.style.transition='none';
  k.style.width=c.offsetWidth+'px';k.style.height=c.offsetHeight+'px';
  k.style.transform=`translate(${c.offsetLeft}px,${c.offsetTop}px)`;k.style.opacity=1;
  if(instant){void k.offsetWidth;k.style.transition=''}
  g.querySelectorAll('.cld').forEach(b=>b.setAttribute('aria-pressed',String(b===c)));
}

/* La altura se anima cuando el mes tiene 5 o 6 semanas */
function fit(){const r=rowsOf(year,month);CW.style.height=`calc(var(--ch)*${r} + ${(r-1)*5}px)`}

/* Detener una transición en curso sin que nada salte */
const curX=()=>{const t=getComputedStyle(cg).transform;return t&&t!=='none'?new DOMMatrix(t).m41:0};
function settle(){
  if(!pend)return 0;
  const x=curX();
  pend.anims.forEach(a=>a.cancel());
  pend.old.remove();
  cg.style.transform=x?`translateX(${x}px)`:'';
  pend=null;return x;
}
function track(old,anims,after){
  const me=pend={old,anims};
  anims[anims.length-1].finished.then(()=>{
    if(pend!==me)return;
    anims.forEach(a=>a.cancel());after();pend=null;
  },()=>{});
}
/* Deslizar de un mes a otro. dir: +1 siguiente, -1 anterior. from: desplazamiento actual en px */
function run(old,ng,dir,from){
  const W=CW.offsetWidth,o={duration:RM?1:480,easing:EASE,fill:'forwards'};
  old.style.transform=ng.style.transform='';
  const a=old.animate([{transform:`translateX(${from}px)`,opacity:1},{transform:`translateX(${-dir*W}px)`,opacity:.25}],o);
  const b=ng.animate([{transform:`translateX(${dir*W+from}px)`,opacity:.25},{transform:'none',opacity:1}],o);
  track(old,[a,b],()=>old.remove());
}
/* Soltar sin llegar al umbral: vuelve a su sitio */
function back(old,nb,dir,dx){
  const W=CW.offsetWidth,o={duration:RM?1:380,easing:EASE,fill:'forwards'};
  old.style.transform=nb.style.transform='';
  const a=old.animate([{transform:`translateX(${dx}px)`},{transform:'none'}],o);
  const b=nb.animate([{transform:`translateX(${dir*W+dx}px)`},{transform:`translateX(${dir*W}px)`}],o);
  track(nb,[a,b],()=>nb.remove());
}
/* Mismo mes reconstruido (p. ej. tras guardar): fundido cruzado */
function fade(old,ng){
  const o={duration:RM?1:360,easing:'ease',fill:'forwards'};
  const a=old.animate([{opacity:1},{opacity:0}],o),b=ng.animate([{opacity:0},{opacity:1}],o);
  track(old,[a,b],()=>old.remove());
}

function lbl(dir){
  const s=$('#clml');s.textContent=`${MONTHS[month]} ${year}`;
  if(dir&&!RM)s.animate([{opacity:0,transform:`translateX(${dir*18}px)`},{opacity:1,transform:'none'}],{duration:420,easing:EASE});
}
function calTot(reset){
  const mt=TX.filter(t=>t.d.startsWith(`${year}-${pad(month+1)}`)),E=sumOf(mt,t=>t.a<0),In=sumOf(mt,t=>t.a>0);
  if(reset)shown.ce=shown.ci=shown.cb=0;
  tween($('#cse'),'ce',E);tween($('#csi'),'ci',In);tween($('#csb'),'cb',r2(In-E));
}

/* Panel del día seleccionado */
function detail(swap,first){
  const L=$('#cdl'),H=$('#cdh');clearTimeout(dt);
  const draw=()=>{
    const ds=dkey(year,month,selD),g=TX.filter(t=>t.d===ds),e=sumOf(g,t=>t.a<0),inc=sumOf(g,t=>t.a>0),dd=new Date(year,month,selD);
    H.innerHTML=`<b>${dd.toLocaleDateString(LOC,{weekday:'long'})}, ${MONTHS[month]} ${selD}</b><span>${e?`${_('Expenses')}: ${cs()+f2(e)}`:''}${inc?`<em>${_('Income')}: ${cs()+f2(inc)}</em>`:''}</span>`;
    let h='';
    g.forEach((t,i)=>{const c=CATS[t.c];
      h+=transactionRow(t,Math.min(i,10));});
    if(!h)h=`<div class="empty"><svg viewBox="0 0 24 24">${I.salary}</svg><b>${_('No transactions')}</b><span>${_('Tap + to add one')}</span></div>`;
    L.style.setProperty('--o',first?'380ms':'0ms');
    L.className='cdl in';L.innerHTML=h;
  };
  if(swap&&!RM){
    L.classList.add('out');
    dt=setTimeout(()=>{L.scrollTop=0;draw();H.classList.remove('sw');void H.offsetWidth;H.classList.add('sw')},170);
  }else draw();
}

/* Cambiar el mes activo (comparte year/month con la pantalla Home) */
function setMonth(y,m,d,dir){
  year=y;month=m;$('#pyr').textContent=y;$('#pm').textContent=MONTHS[m];
  selD=d||defDay(y,m);
  render(false);lbl(dir);calTot();detail(true);
}
function calGo(y,m,d,force){
  const dir=Math.sign((y*12+m)-(year*12+month));
  if(!dir&&!force)return;
  const from=settle(),old=cg;
  setMonth(y,m,d,dir);
  const ng=buildGrid(y,m);CW.appendChild(ng);cg=ng;ring(ng,selD,true);fit();
  if(dir)run(old,ng,dir,from);else fade(old,ng);
}
function calAfter(y,m,d){
  calGo(y,m,d,true);
  setTimeout(()=>{
    const c=cg&&cg.querySelector(`.cld[data-d="${d}"]`);
    if(c&&!RM)c.animate([{transform:'scale(.72)'},{transform:'scale(1.14)'},{transform:'none'}],{duration:560,easing:'cubic-bezier(.34,1.56,.64,1)'});
  },420);
}
function pickDay(d){if(d===selD)return;selD=d;ring(cg,d);detail(true)}

function calOpen(){
  if(calOn)return;calOn=true;settle();
  selD=defDay(year,month);
  const g=buildGrid(year,month);g.classList.add('in');g.style.setProperty('--d','260ms');
  CW.replaceChildren(g);cg=g;fit();ring(g,selD,true);
  $('#clml').textContent=`${MONTHS[month]} ${year}`;
  calTot(true);detail(false,true);
  $('#app').classList.add('calon');CL.inert=false;CL.classList.add('on');
}
function calClose(){
  if(!calOn)return;calOn=false;
  $('#app').classList.remove('calon');CL.classList.remove('on');CL.inert=true;sheet(false);
}

/* Arrastrar la cuadrícula para cambiar de mes: sigue al dedo y termina con inercia */
CW.addEventListener('pointerdown',e=>{
  if(pend||e.button>0)return;
  dr={x:e.clientX,y:e.clientY,id:e.pointerId,on:false,dir:0,dx:0,lx:e.clientX,lt:performance.now(),v:0,nb:null};
});
CW.addEventListener('pointermove',e=>{
  if(!dr||e.pointerId!==dr.id)return;
  const dx=e.clientX-dr.x,dy=e.clientY-dr.y;
  if(!dr.on){
    if(Math.abs(dy)>14&&Math.abs(dy)>Math.abs(dx)){dr=null;return}
    if(Math.abs(dx)<10||Math.abs(dx)<Math.abs(dy)*1.2)return;
    dr.on=true;try{CW.setPointerCapture(e.pointerId)}catch(_){}
  }
  const dir=dx<0?1:-1,W=CW.offsetWidth;
  if(dir!==dr.dir){
    if(dr.nb)dr.nb.remove();
    dr.dir=dir;[dr.ty,dr.tm]=nbOf(dir);
    dr.nb=buildGrid(dr.ty,dr.tm);CW.appendChild(dr.nb);ring(dr.nb,defDay(dr.ty,dr.tm),true);
  }
  const now=performance.now();
  dr.v=dr.v*.6+.4*((e.clientX-dr.lx)/Math.max(1,now-dr.lt));dr.lx=e.clientX;dr.lt=now;dr.dx=dx;
  cg.style.transform=`translateX(${dx}px)`;
  dr.nb.style.transform=`translateX(${dir*W+dx}px)`;
});
function endDrag(e){
  if(!dr||e.pointerId!==dr.id)return;
  const d=dr;dr=null;
  if(!d.on)return;
  dragged=true;setTimeout(()=>dragged=false,60);
  const W=CW.offsetWidth,commit=Math.abs(d.dx)>W*.22||(Math.abs(d.v)>.45&&Math.sign(d.v)===Math.sign(d.dx));
  const old=cg,nb=d.nb;
  if(commit){setMonth(d.ty,d.tm,0,d.dir);cg=nb;fit();run(old,nb,d.dir,d.dx)}
  else back(old,nb,d.dir,d.dx);
}
CW.addEventListener('pointerup',endDrag);
CW.addEventListener('pointercancel',endDrag);
CW.addEventListener('click',e=>{const b=e.target.closest('.cld');if(b&&!dragged&&b.parentNode===cg)pickDay(+b.dataset.d)});

/* Botones */
$('#clb').onclick=calClose;
$('#clp').onclick=()=>{const[y,m]=nbOf(-1);calGo(y,m)};
$('#clx').onclick=()=>{const[y,m]=nbOf(1);calGo(y,m)};
$('#clm').onclick=()=>{tgt='home';sheet(true)};
$('#clto').onclick=()=>{const n=new Date(),y=n.getFullYear(),m=n.getMonth();y===year&&m===month?pickDay(n.getDate()):calGo(y,m)};
$('#clf').onclick=()=>openAdd(dkey(year,month,selD));
addEventListener('resize',()=>{if(calOn&&cg&&!pend)ring(cg,selD,true)});
addEventListener('keydown',e=>{
  if(!calOn||$('#add').classList.contains('on'))return;
  const open=$('#app').classList.contains('open');
  if(e.key==='Escape'&&!open)calClose();
  else if(!open&&(e.key==='ArrowLeft'||e.key==='ArrowRight')){const[y,m]=nbOf(e.key==='ArrowRight'?1:-1);calGo(y,m)}
},true);

/* Abrir "Add": desde el calendario guarda en el día seleccionado */
function openAdd(date){
  resetDraft();
  addDate=date;
  let lab=_('Today');
  if(date){const d=new Date(date+'T00:00');lab=`${MONTHS[d.getMonth()]} ${d.getDate()}`}
  $('.k.td').innerHTML=KI.t.replace('Today',lab);
  setAdd(true);
}

/* Reports: Analytics / Accounts */
const fm=n=>cs()+(Number.isInteger(n)?n:f2(n));
function rep(E,In){$('#rsm').textContent=MONTHS[month];$('#re').textContent=fm(E);$('#ri').textContent=fm(In);$('#rb').textContent=fm(r2(In-E));$('#rbe').textContent=fm(E);
  updateReport();
  $('#fn').textContent=TX.length;$('#fd').textContent=new Set(TX.map(t=>t.d)).size}
const RB=[...document.querySelectorAll('#rseg button')],RP=['rn','ra'];
RB.forEach((b,i)=>b.onclick=()=>{
  $('#rseg').style.setProperty('--s',i);
  RB.forEach((x,j)=>x.classList.toggle('on',j===i));
  RP.forEach((id,j)=>{const e=$('#'+id);e.classList.toggle('left',j<i);e.classList.toggle('on',j===i);if(j===i)e.scrollTop=0});
});
$('#rst').onclick=()=>show(0);

/* Tile +: añadir categoría */
const NI=[
['Entertainment',[
A.fun,
'<path d="M7 8h10a4 4 0 0 1 4 4v1a3 3 0 0 1-5 2l-1-1H9l-1 1a3 3 0 0 1-5-2v-1a4 4 0 0 1 4-4zM8 10v3M6.5 11.5h3M15.5 11h.01M17.5 12.5h.01"/>',
'<path d="M6 20V11a6 6 0 0 1 12 0v9l-2-2-2 2-2-2-2 2-2-2zM10 11h.01M14 11h.01"/>',
'<path d="M10 4h4v3h-4zM8 7h8v4H8zM6 11h12v4H6zM4 15h16v4H4z"/>',
'<circle cx="10" cy="10" r="6"/><path d="m14 14 6 6M18 5h.01"/>',
'<path d="m10 14-6 6M8 12l4 4 7-2 2-7zM14 7l3 3"/>',
'<rect x="4" y="4" width="16" height="16" rx="1"/><path d="M9.3 4v16M14.7 4v16M4 9.3h16M4 14.7h16"/>',
'<rect x="3" y="8" width="18" height="12" rx="2"/><path d="m6 8 12-4M7 14h6M16 13h.01M16 16h.01"/>',
'<rect x="3" y="9" width="18" height="11" rx="1"/><path d="m3 9 2-5h3L6 9M9 9l2-5h3l-2 5M15 9l2-5h3l-2 5M10 13l4 2-4 2z"/>',
'<rect x="6" y="8" width="12" height="9" rx="2"/><path d="M12 8V4M9 12h.01M15 12h.01M10 15h4M4 11v3M20 11v3M9 20v-3M15 20v-3"/>',
'<rect x="7" y="3" width="10" height="18" rx="2"/><rect x="9" y="5" width="6" height="6"/><path d="M10 15v3M8.5 16.5h3M15 16h.01M16 18h.01"/>',
'<circle cx="12" cy="7" r="3"/><path d="M10.5 10h3l1.5 6H9zM7 20h10v-2H7z"/>',
'<circle cx="9" cy="15" r="6"/><path d="M8 13h.01M10.5 12.5h.01M9 16h.01M17 4c-1 2-1 4 0 6l2-1c1-2 0-4-2-5z"/>',
'<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M8.5 8.5h.01M15.5 8.5h.01M12 12h.01M8.5 15.5h.01M15.5 15.5h.01"/>',
'<path d="M9 18V5l11-2v13M9 18a3 3 0 1 1-3-3 3 3 0 0 1 3 3zM20 16a3 3 0 1 1-3-3 3 3 0 0 1 3 3z"/>'
]],
['Food',[
'<path d="M6 10a4 4 0 0 1 2-6h8a4 4 0 0 1 2 6v9H6zM10 10v4M14 10v4"/>',
'<path d="M6 4h12l-1 17H7zM9 9h6v6H9z"/>',
'<path d="m5 15 10-10a2.8 2.8 0 0 1 4 4L9 19a2.8 2.8 0 0 1-4-4zM9 11l4 4"/>',
'<rect x="8" y="8" width="8" height="8" rx="4"/><path d="m8 10-4-1v6l4-1M16 10l4-1v6l-4-1"/>',
'<path d="M15 4a5 5 0 0 1 2 8l-2.5 2.5-5-5L12 7a5 5 0 0 1 3-3zM9.5 14.5 5 19M4 17l3 3"/>',
'<path d="M3 7c5-4 13-4 18 0L12 21zM9 9h.01M14 10h.01M12 14h.01"/>',
'<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="2.5"/><path d="m6 10 1.5 1M16 7l-1 1.5M17 15l-1.5-1M9 18l1-2"/>',
'<path d="m3 11 15-5 3 8H3zM3 14v5h18v-5M10 9l.5 3"/>',
'<circle cx="8" cy="17" r="3"/><circle cx="16" cy="17" r="3"/><path d="M8 14c1-5 3-8 5-10 0 4 2 7 3 10M13 4c2 0 4 0 6 1"/>',
'<path d="M12 21c-4 0-7-3-7-7 0-3 3-5 7-5s7 2 7 5c0 4-3 7-7 7zM12 9V4M9 5l3 2 3-2"/>',
'<rect x="8" y="3" width="8" height="13" rx="4"/><path d="M12 16v5M10 8h4"/>',
'<path d="M5 9c0-2 3-3 7-3s7 1 7 3c0 5-3 11-7 11S5 14 5 9zM12 6V3M9.5 11h.01M14.5 11h.01M12 14h.01M10 17h.01M14 17h.01"/>',
'<path d="M8 3h8l1 4v14H7V7zM7 7h10M10 12h4v4h-4z"/>',
'<path d="M6 10h12l-1.5 11h-9zM8 10V5M11 10V3M14 10V4M17 10V6"/>',
'<path d="M7 8h10l-1 13H8zM12 8V3l3-1M7 12h10"/>',
'<path d="M4 12h16a8 8 0 0 1-16 0zM8 20h8M7 12c1-3 3-4 5-4s4 1 5 4"/>',
'<path d="M3 12c3-5 9-6 13-3l5-3v12l-5-3c-4 3-10 2-13-3zM8 11h.01"/>',
'<path d="M5 8h11v12H5zM16 10h3a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1h-3M8 11v6M12 11v6M5 8a3 3 0 0 1 3-4 3 3 0 0 1 5 0 3 3 0 0 1 3 4"/>',
'<path d="M7 11a5 5 0 0 1 10 0zM7 11l5 10 5-10"/>',
'<path d="M4 11a8 6 0 0 1 16 0zM3 14h18M4 17h16v1a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/>',
'<path d="M12 9c-3 0-5 3-5 7s2 5 5 5 5-1 5-5-2-7-5-7zM12 9V4M9 5l3 3 3-3M9 14l6 5M15 14l-6 5"/>',
'<path d="M12 7C9 5 4 6 4 12c0 5 3 9 6 8 1 0 1.5-.5 2-.5s1 .5 2 .5c3 1 6-3 6-8 0-6-5-7-8-5zM12 7c0-2 1-3 3-4"/>',
'<path d="M3 8a9 9 0 0 0 18 0zM6 8a6 6 0 0 0 12 0M9 11h.01M12 13h.01M15 11h.01"/>',
A.carrot,A.grapes,A.muffin
]],
['Shopping',[
'<path d="M6 8h12l1 12H5zM9 8a3 3 0 0 1 6 0"/>',
'<path d="M3 14c2 3 16 3 18 0-2-1-3-2-3-6a6 4 0 0 0-12 0c0 4-1 5-3 6zM6 12c4 1 8 1 12 0"/>',
'<path d="m8 4-5 3 2 4 2-1v10h10V10l2 1 2-4-5-3c-1 2-2 3-4 3S9 6 8 4z"/>',
'<path d="M8 3v6c0 3 2 4 2 6v6M16 3v6c0 3-2 4-2 6v6M8 9h8"/>',
'<path d="M5 5v8c0 3 2 5 5 5h10v-3l-6-1-4-4V5zM16 18v2"/>',
'<path d="M9 3h6l-1 7 5 11H5l5-11zM9 3l3 4 3-4"/>',
'<path d="M8 3h6v9l5 3v5H7v-4l1-13zM8 8h6"/>',
'<rect x="7" y="10" width="10" height="11" rx="3"/><path d="M10 10V7h4v3M9 4h3M16 5h3M17 3v4"/>',
'<path d="M9 3h6l5 5-2 3-3-1v11H9V10l-3 1-2-3zM12 3v18"/>',
'<path d="M5 5h14l1 14h-6l-2-6-2 6H4zM5 8h14"/>',
'<path d="m7 4h10l4 5-9 11L3 9zM3 9h18M9 4 8 9l4 11M15 4l1 5-4 11"/>',
'<rect x="7" y="7" width="10" height="10" rx="3"/><path d="m9 7 1-4h4l1 4M9 17l1 4h4l1-4M12 10v2l1.5 1"/>',
'<rect x="9" y="12" width="6" height="9"/><path d="M10 12V7l4-4v9M5 21h14"/>',
'<path d="M3 12V4h8l10 10-8 8zM7.5 8h.01"/>',
'<circle cx="7" cy="14" r="3.5"/><circle cx="17" cy="14" r="3.5"/><path d="M10.5 14h3M3 14 4 8M21 14l-1-6"/>'
]],
['Life',[
'<path d="M4 9h13v6a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5zM17 10h2a2 2 0 0 1 0 4h-2M8 3v3M12 3v3"/>',
'<path d="M8 3h8v4l-2 3v11h-4V10L8 7zM8 7h8"/>',
'<path d="M3 12h18v3a5 5 0 0 1-5 5H8a5 5 0 0 1-5-5zM6 12V6a2 2 0 0 1 4 0M7 20l-1 2M17 20l1 2"/>',
'<rect x="3" y="7" width="18" height="13" rx="2"/><path d="m8 3 4 4 4-4"/>',
'<path d="M4 20V10l8-6 8 6v10zM10 20v-6h4v6"/>',
'<rect x="3" y="5" width="18" height="8" rx="2"/><path d="m6 17-1 3M12 17v3M18 17l1 3M7 9h10"/>',
'<path d="M3 12a9 8 0 0 1 18 0zM12 12v7a2 2 0 0 1-4 0"/>',
'<path d="M6 3h12l-2 11H8zM8 14v3h8v-3M7 17l-1 4h12l-1-4M10 8h4"/>',
'<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
'<path d="M3 19V6M3 15h18v4M21 15v-3a3 3 0 0 0-3-3h-7v6M7 12h.01"/>',
'<path d="M5 11V8a3 3 0 0 1 3-3h8a3 3 0 0 1 3 3v3M3 13a2 2 0 0 1 4 0v2h10v-2a2 2 0 0 1 4 0v5H3zM6 18v2M18 18v2"/>',
A.cabinet,
'<path d="M9 3h6l3 9H6zM12 12v8M8 20h8"/>',
'<rect x="5" y="3" width="14" height="18" rx="2"/><circle cx="12" cy="14" r="4"/><path d="M8 7h.01M11 7h2"/>',
'<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8M9 12h.01M12 12h.01M15 12h.01M9 16h.01M12 16h.01M15 16h.01"/>',
'<path d="M3 9a5 5 0 0 1 5-5h8a4 4 0 0 1 0 8H8a5 5 0 0 1-5-3zM14 12l-1 8h-3l1-8"/>',
'<circle cx="12" cy="12" r="9"/><path d="M12 12c-3-2-3-6 0-6M12 12c3-2 6 0 5 3M12 12c0 3-3 5-6 3"/>',
'<path d="M12 10V8a2 2 0 1 1 2.5 2L3 18h18z"/>'
]],
['Personal',[
A.haircut,
'<rect x="4" y="11" width="16" height="9" rx="3"/><path d="M8 11V8M12 11V5M16 11V8"/>',
'<rect x="8" y="10" width="8" height="11" rx="1"/><path d="M12 10V8M12 3c-2 2-2 4 0 5 2-1 2-3 0-5z"/>',
'<path d="M14 10 20 4M17 3l4 4M11 9l4 4-3 4a4 4 0 1 1-5-5z"/>',
'<circle cx="12" cy="9" r="2.5"/><circle cx="12" cy="4.5" r="1.8"/><circle cx="12" cy="13.5" r="1.8"/><circle cx="7.5" cy="9" r="1.8"/><circle cx="16.5" cy="9" r="1.8"/><path d="M12 15.5V21"/>',
'<path d="M6 20h12l-1-3a7 7 0 1 0-10 0zM9 11h.01M13 9h.01M14 13h.01"/>',
'<path d="M7 4h6v9H7zM9 13v5M5 18h8M13 12h5v3"/>',
'<path d="M8 3h8l-1 5 3 3v10H6V11l3-3zM9 15h6"/>',
'<circle cx="12" cy="9" r="4.5"/><circle cx="7" cy="5" r="1.5"/><circle cx="17" cy="5" r="1.5"/><path d="M10 9h.01M14 9h.01M11 11h2M8 14l-3 3 2 3 3-2M16 14l3 3-2 3-3-2M10 20h4"/>',
'<path d="M7 21h10l-1.5-7h-7zM12 14V9M12 9c0-4-4-5-6-4 0 3 2 5 6 4zM12 11c0-3 3-4 5-3 0 3-2 4-5 3z"/>'
]],
['Education',[
'<path d="M3 5h7a2 2 0 0 1 2 2v13a2 2 0 0 0-2-2H3zM21 5h-7a2 2 0 0 0-2 2v13a2 2 0 0 1 2-2h7z"/>',
'<path d="M4 4h4v16H4zM9 4h4v16H9zM14.5 5l4-1 3 14-4 1z"/>',
'<path d="M3 10 12 4l9 6zM5 10v8M9 10v8M15 10v8M19 10v8M3 20h18"/>',
'<rect x="4" y="8" width="16" height="12" rx="2"/><path d="M9 8V5h6v3M4 13h16"/>',
'<path d="M4 20V4l16 16zM8 15v-5M8 15h5"/>',
'<path d="m4 12 14-6 2 4L6 16zM9 14l-3 7M13 12l3 9"/>',
'<circle cx="12" cy="12" r="5"/><ellipse cx="12" cy="12" rx="10" ry="4" transform="rotate(-25 12 12)"/>',
'<path d="m10 3 4 2-3 7-4-2zM9 14a5 5 0 1 0 8-1M5 21h14"/>',
'<path d="M12 3a9 9 0 1 0 0 18c1.5 0 2-1 1.5-2s0-2.5 1.5-2.5H17a4 4 0 0 0 4-4c0-5-4-9.5-9-9.5zM7.5 11h.01M10 7.5h.01M14.5 7.5h.01M17 11h.01"/>',
'<path d="M4 20l1-5L16 4l4 4L9 19zM14 6l4 4"/>',
'<path d="m2 9 10-5 10 5-10 5zM6 11v5c3 3 9 3 12 0v-5M22 9v6"/>',
'<path d="M9 3h6M10 3v6l-5 10a1.5 1.5 0 0 0 1.5 2h11A1.5 1.5 0 0 0 19 19l-5-10V3M8 15h8"/>',
'<path d="M3 4h18M5 4v10h14V4M12 14v4M8 21l4-3 4 3M8 11l3-3 2 2 3-3"/>',
'<rect x="5" y="3" width="12" height="18" rx="1"/><path d="M9 8h4M9 12h4M17 12l4-4 1 1-4 4z"/>'
]],
['Festival',[
'<path d="M4 19h16M6 19c0-8 3-13 11-14l2 3c-2 2-1 6-1 11"/><circle cx="19" cy="6" r="2"/>',
'<path d="M12 7C5 5 3 10 4 14c1 4 5 6 8 6s7-2 8-6c1-4-1-9-8-7zM12 7V4M8 12l2 2M16 12l-2 2M9 17c2 1 4 1 6 0"/>',
'<path d="m3 21 5-13 8 8zM11 5l1-2M15 7l3-3M17 11l3-1"/>',
'<path d="m5 21 4-10 3 1-4 10zM14 21l4-10 3 1-4 9zM11 3v4M5 4l2 3M17 4l-2 3"/>',
'<circle cx="12" cy="6" r="3"/><circle cx="12" cy="16" r="5"/><path d="M11 6h.01M13 6h.01M12 14h.01M12 17h.01"/>',
'<path d="M8 3h7v9l6 4a3 3 0 0 1-3 5l-9-5a3 3 0 0 1-1-2zM8 7h7"/>',
'<path d="M9 21V8a4 4 0 0 1 8 0M9 17l4-2M9 12l4-2"/>',
'<rect x="4" y="12" width="16" height="8" rx="1"/><path d="M4 16c3 2 5-2 8 0s5-2 8 0M8 12V8M12 12V8M16 12V8M8 4v1M12 4v1M16 4v1"/>',
A.gift,
'<path d="M12 3c-4 0-6 3-6 6 0 4 3 7 6 7s6-3 6-7c0-3-2-6-6-6zM12 16l-1 2h2zM12 18c0 2-2 2-2 4"/>'
]],
['Sports',[
A.sports,
'<path d="M5 4c9 0 15 6 15 15M5 4c0 9 6 15 15 15M4 20 17 7M17 4v3h3"/>',
'<path d="M7 4v14M7 4l8 3-8 3M5 20h10"/><circle cx="17" cy="18" r="1.5"/>',
'<path d="m5 5 14 14M19 5 5 19M4 4l3 1-1 3zM20 4l-3 1 1 3z"/>',
'<path d="M6 10c0-4 3-6 7-6s6 3 6 6v4a4 4 0 0 1-4 4v3H8v-4c-1-1-2-3-2-5zM13 11h4"/>',
'<ellipse cx="9" cy="9" rx="5" ry="6" transform="rotate(-45 9 9)"/><path d="m13 13 7 7M6 6l6 6"/>',
'<circle cx="12" cy="12" r="9"/><path d="M6 5c3 3 3 11 0 14M18 5c-3 3-3 11 0 14"/>',
'<path d="M4 20C4 10 10 4 20 4c0 10-6 16-16 16zM9 15l6-6M10 10l4 4"/>',
'<circle cx="12" cy="12" r="9"/><path d="m12 8 3 2-1 4h-4l-1-4zM12 3v5M20 9l-5 1M17 19l-3-5M7 19l3-5M4 9l5 1"/>',
'<circle cx="7" cy="17" r="3"/><circle cx="18" cy="17" r="3"/><path d="m7 17 4-8h4l3 8M9 6h4M12 17l-1-8"/>',
'<path d="M3 9v6M6 7v10M18 7v10M21 9v6M6 12h12"/>',
'<circle cx="12" cy="5" r="2"/><path d="M5 14c4 1 6-1 7-4 1 3 3 5 7 4M8 20l4-4 4 4M12 8v8"/>',
'<path d="M5 19l1-4L18 3l3 3L9 18zM4 20l2-1"/>'
]],
['Office',[
'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
'<path d="M4 10v4h3l8 4V6L7 10zM18 9a4 4 0 0 1 0 6M7 14l1 6h3l-1-5"/>',
'<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 7h8M8 12h.01M12 12h.01M16 12h.01M8 16h.01M12 16h.01M16 16h.01"/>',
'<rect x="7" y="9" width="10" height="12" rx="1"/><path d="M9 9V3h6v6M11 5h.01M13 5h.01"/>',
'<path d="M4 4h13l3 3v13H4zM8 4v5h8V4M8 20v-6h8v6"/>',
'<rect x="7" y="3" width="10" height="18" rx="5"/><path d="M12 3v7M7 10h10"/>',
'<path d="m20 11-8 8a5 5 0 0 1-7-7l9-9a3.5 3.5 0 0 1 5 5l-9 9a2 2 0 0 1-3-3l8-8"/>',
'<rect x="3" y="14" width="18" height="6" rx="2"/><path d="M7 17h.01M11 17h.01M7 11a7 7 0 0 1 10 0M9.5 8.5a3.5 3.5 0 0 1 5 0"/>',
'<rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M7 14h10"/>',
'<path d="M7 9V3h10v6M7 17H4V9h16v8h-3M7 14h10v7H7z"/>',
'<rect x="3" y="4" width="18" height="12" rx="1"/><path d="M9 20h6M12 16v4"/>',
'<path d="M6 3h9l4 4v6M6 3v18h8M9 9h6M9 13h4M15 20l1 1 5-5-1-1z"/>',
'<path d="M7 18a4.5 4.5 0 0 1-.5-9A6 6 0 0 1 18 10a4 4 0 0 1 0 8z"/>'
]],
['Transport',[
'<path d="M5 17v-5l2-5h10l2 5v5zM5 17v2h3v-2M16 17v2h3v-2M7 12h10M8 15h.01M16 15h.01"/>',
A.trans,A.plane,
'<path d="M3 16l2 4h14l2-4zM6 16v-5h12v5M9 11V7h6v4"/>',
'<path d="M4 5h16M12 5v3M5 14a6 6 0 0 1 6-6h4a4 4 0 0 1 4 4v3a2 2 0 0 1-2 2H8a3 3 0 0 1-3-3zM9 19h8"/>',
'<circle cx="6" cy="16" r="3"/><circle cx="18" cy="16" r="3"/><path d="m6 16 4-6h5l3 6M10 10 9 7H6M14 10l1-4h3M10 16h5"/>',
'<path d="M12 3v13M12 4c4 3 6 7 6 11h-6M12 8c-3 2-5 4-5 8h5M4 18h16l-3 3H7z"/>',
'<circle cx="6" cy="18" r="2.5"/><circle cx="18" cy="18" r="2.5"/><path d="M6 18h12l-2-9h3M10 9h4"/>',
'<circle cx="6" cy="16" r="3.5"/><circle cx="18" cy="16" r="3.5"/><path d="m6 16 4-8h6l2 8M10 8H8M12 16l-2-8M12 16h6"/>',
'<path d="M5 21V4h9v17M5 21h9M5 9h9M14 8l3 2v8a1.5 1.5 0 0 0 3 0v-6l-3-3"/>',
'<path d="M3 6h11v10H3zM14 9h4l3 4v3h-7"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>'
]],
['Health',[
'<path d="m16 3 5 5M14 5l5 5M12 7l5 5-9 9H4v-4zM8 13l3 3M3 21l2-2"/>',
'<rect x="3" y="9" width="18" height="6" rx="3" transform="rotate(-45 12 12)"/><path d="m9 9 6 6"/>',
'<path d="M12 5a3 3 0 0 0-6 1 3 3 0 0 0-2 5 3 3 0 0 0 1 5 3 3 0 0 0 6 2V5zM12 5a3 3 0 0 1 6 1 3 3 0 0 1 2 5 3 3 0 0 1-1 5 3 3 0 0 1-6 2M9 10h3M12 14h3"/>',
'<path d="M6 3v6a4 4 0 0 0 8 0V3M4 3h3M13 3h3M10 13v2a5 5 0 0 0 10 0v-2"/><circle cx="20" cy="11" r="2"/>',
'<path d="M2 17V7h12v10M14 10h4l4 4v3h-8M8 10v4M6 12h4"/><circle cx="6" cy="18" r="1.5"/><circle cx="18" cy="18" r="1.5"/>',
'<path d="M7 4c-3 0-4 3-3 7 1 3 1 9 3 9 2 0 1-6 5-6s3 6 5 6c2 0 2-6 3-9 1-4 0-7-3-7-2 0-3 1-5 1S9 4 7 4z"/>',
'<path d="M12 20S4 15 4 9a4 4 0 0 1 8-1 4 4 0 0 1 8 1c0 6-8 11-8 11zM7 12h3l1.5-3 2 5 1.5-2h2"/>',
'<rect x="2" y="9" width="20" height="6" rx="3" transform="rotate(45 12 12)"/><path d="M10 10h.01M14 14h.01M14 10h.01M10 14h.01"/>',
'<path d="M10 14V5a2 2 0 0 1 4 0v9a4 4 0 1 1-4 0zM12 9v7"/>',
A.health
]],
['Travel',[
'<rect x="4" y="8" width="16" height="12" rx="2"/><path d="M9 8V5h6v3M9 12v4M15 12v4"/>',
'<path d="M12 20V10M12 10C9 6 5 7 4 9c3-1 6 0 8 1zM12 10c3-4 7-3 8-1-3-1-6 0-8 1zM12 10C11 7 11 5 13 3c1 2 0 5-1 7zM4 20h16"/>',
'<path d="M3 17c2-1 3 1 5 0s3 1 5 0 3 1 5 0 2 .5 3 0M8 13l3-4 3 2"/><circle cx="14" cy="6" r="1"/>',
'<path d="M12 4v11M12 5c3 2 5 5 5 9h-5zM4 17h16l-3 4H7z"/>',
'<path d="M4 17a8 8 0 0 1 16 0zM3 20h18M12 9V7M10 7h4"/>',
'<path d="M4 4h16l-8 9zM12 13v7M8 20h8M17 4l3-2"/>',
'<path d="M12 21c-5-5-7-8-7-11a7 7 0 0 1 14 0c0 3-2 6-7 11z"/><circle cx="12" cy="10" r="2.5"/>',
'<path d="m3 20 9-15 9 15zM12 5v15M9 20l3-6 3 6"/>',
'<path d="M3 8h18v3a2 2 0 0 0 0 4v3H3v-3a2 2 0 0 0 0-4zM14 8v10"/>',
A.shopping
]],
['Finance',[
'<circle cx="12" cy="12" r="9"/><path d="M14.5 9c-.5-1-1.500-1.500-2.500-1.500-1.500 0-2.500.8-2.500 2s1 1.800 2.500 2 2.500.8 2.500 2-1 2-2.500 2c-1 0-2-.5-2.500-1.500M12 6v1.500M12 16.500V18"/>',
'<path d="M4 20h16M7 20v-7M12 20V6M17 20v-10"/>',
'<rect x="3" y="6" width="18" height="13" rx="2"/><path d="m3 8 9 6 9-6"/>',
'<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v12c0 1.700 3.500 3 8 3s8-1.300 8-3V6M4 12c0 1.700 3.500 3 8 3s8-1.300 8-3"/>',
'<rect x="6" y="3" width="12" height="18" rx="2"/><path d="m9 14 2-2 2 1 2-3"/>',
'<path d="M3 7a2 2 0 0 1 2-2h12v3M3 7v11a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1V9a1 1 0 0 0-1-1H5a2 2 0 0 1-2-1zM17 14h.01"/>',
'<rect x="3" y="6" width="18" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/><path d="M6 9h.01M18 15h.01"/>',
'<path d="M7 20V8M4 11l3-3 3 3M17 4v12M14 13l3 3 3-3"/>',
'<path d="M3 8h18v11H3zM8 8V5h8v3M3 13h18"/>',
'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18M7 15h4"/>',
'<path d="M5 12c0-3 3-5 7-5h3l2-2v3c2 1 3 2 3 4v3l-2 1v2h-3v-2H9v2H6v-3c-1-1-1-2-1-3zM15 11h.01"/>'
]],
['Others',[
'<circle cx="7" cy="16" r="4"/><circle cx="17" cy="16" r="4"/><path d="M11 16h2M5 12l1-6h3l1 6M14 12l1-6h3l1 6"/>',
'<path d="m12 12-8-5v10zM12 12l8-5v10z"/>',
'<path d="m3 10 9-6 9 6v10H3zM3 10l9 6 9-6"/>',
'<path d="M5 14a8 8 0 0 0 8 8M4 9l8 8 3-3-8-8zM14 5a5 5 0 0 1 5 5M14 8a2 2 0 0 1 2 2"/>',
'<rect x="6" y="6" width="12" height="12" rx="1"/><path d="M9 3v3M12 3v3M15 3v3M9 18v3M12 18v3M15 18v3M3 9h3M3 12h3M3 15h3M18 9h3M18 12h3M18 15h3M10 10h4v4h-4z"/>',
'<path d="M8 4h8v6a4 4 0 0 1-8 0zM8 6H4v1a4 4 0 0 0 4 4M16 6h4v1a4 4 0 0 1-4 4M12 14v4M8 20h8M9 18h6"/>',
'<circle cx="12" cy="9" r="5"/><path d="m9 13-2 8 5-3 5 3-2-8M12 7v4"/>',
'<path d="m14 4 6 6-3 3-6-6zM12 8l-8 8 3 3 8-8M4 21h9"/>',
'<path d="M3 4h3l2 12h10M9 8h10l-1 5H9.5M10 20h.01M17 20h.01"/>',
'<circle cx="9" cy="9" r="3"/><path d="M9 3v2M9 13v2M3 9h2M13 9h2M5 5l1 1M12 12l1 1M13 5l-1 1M5 13l1-1"/><circle cx="17" cy="17" r="2"/>',
'<rect x="5" y="3" width="14" height="18" rx="2"/><path d="m8 8 1 1 2-2M13 8h3M8 14l1 1 2-2M13 14h3"/>',
'<path d="M12 7v12M12 9C9 3 3 4 4 9c.5 3 5 4 8 3M12 9c3-6 9-5 8 0-.5 3-5 4-8 3M12 13c-4 0-6 4-4 6s4 0 4-3M12 13c4 0 6 4 4 6s-4 0-4-3"/>'
]]
];
const NCOL=[['#ff6b6b','#ec7567','#d4958a','#ff7a1a','#ffb57d'],['#e6b03a','#cdb42a','#82b520','#3acd24','#26cf96','#68c4cc'],['#44aadb','#4c87ff','#9a8cff','#c07fe0','#f4729f']];
const lt=h=>'#'+[1,3,5].map(i=>Math.round(parseInt(h.substr(i,2),16)*.45+140).toString(16).padStart(2,'0')).join('');
const NC={t:0,c:'#f4729f',i:'0-0'},ip=i=>{const[s,j]=i.split('-');return NI[s][1][j]};
$('#n-pal').innerHTML=NCOL.map(r=>`<div>${r.map(c=>`<button class="sw" data-c="${c}" style="background:${c}" aria-label="Color"><svg viewBox="0 0 24 24"><path d="m5 12 5 5 9-10"/></svg></button>`).join('')}</div>`).join('');
$('#n-ics').innerHTML=NI.map(([t,l],s)=>`<h4>${t}</h4><div class="pg">${l.map((p,i)=>`<button class="pk" data-i="${s}-${i}"><svg viewBox="0 0 24 24">${p}</svg></button>`).join('')}</div>`).join('');
function ncSet(){
  const s=$('#nc');s.style.setProperty('--a',NC.c);s.style.setProperty('--b',lt(NC.c));
  $('#n-pv').innerHTML=ip(NC.i);
  document.querySelectorAll('#n-rd button').forEach(b=>b.classList.toggle('on',+b.dataset.t===NC.t));
  document.querySelectorAll('.sw').forEach(b=>b.classList.toggle('on',b.dataset.c===NC.c));
  document.querySelectorAll('.pk').forEach(b=>b.classList.toggle('on',b.dataset.i===NC.i));
}
function openNc(){
  Object.assign(NC,{t:curSeg===1?1:0,c:'#f4729f',i:'0-0'});$('#n-nm').value='';ncSet();
  $('#nbody').scrollTop=0;$('#nc').inert=false;$('#nc').classList.add('on');
}
function ncClose(){$('#nc').classList.remove('on');$('#nc').inert=true;$('#n-nm').blur()}

$('#n-rd').onclick=e=>{const b=e.target.closest('button');if(b){NC.t=+b.dataset.t;ncSet()}};
$('#n-pal').onclick=e=>{const b=e.target.closest('.sw');if(b){NC.c=b.dataset.c;ncSet()}};
$('#n-ics').onclick=e=>{const b=e.target.closest('.pk');if(b&&NC.i!==b.dataset.i){NC.i=b.dataset.i;ncSet()}};
$('#nx').onclick=ncClose;

/* Profile → Icon: estilo de iconos */
const ST={ic:'gradient',add:'color'},CK='<svg class="ck" viewBox="0 0 24 24"><path d="m5 12 5 5 9-10"/></svg>';
try{Object.assign(ST,JSON.parse(localStorage.getItem('mt-icons')||'{}'))}catch(e){}
const SM=[['shopping','#f2c94c','#fbeab5'],['food','#2fd39b','#c2f4df'],['phone','#ff7fa8','#ffd0df'],['fun','#5bd65b','#c9f2c0'],['edu','#ff8a3d','#ffcfae']];
$('#s-ic').innerHTML=[['gradient','gd'],['solid','sd']].map(([v,c])=>`<button data-v="${v}"><span class="ics">${SM.map(([k,a,b])=>`<span class="ic ${c}" style="--a:${a};--b:${b}"><svg viewBox="0 0 24 24">${A[k]}</svg></span>`).join('')}</span>${CK}</button>`).join('');
function applyIc(save){
  $('#app').dataset.ic=ST.ic;$('#app').dataset.add=ST.add;
  document.querySelectorAll('#s-ic button').forEach(b=>b.classList.toggle('on',b.dataset.v===ST.ic));
  document.querySelectorAll('#s-add button').forEach(b=>b.classList.toggle('on',b.dataset.v===ST.add));
  if(save) saveSettings();
}
$('#s-ic').onclick=e=>{const b=e.target.closest('button');if(b){ST.ic=b.dataset.v;applyIc(1)}};
$('#s-add').onclick=e=>{const b=e.target.closest('button');if(b){ST.add=b.dataset.v;applyIc(1)}};
$('#pic').onclick=()=>{$('#sub').inert=false;$('#sub').classList.add('on')};
$('#sx').onclick=()=>{$('#sub').classList.remove('on');$('#sub').inert=true};
applyIc();

/* Sonidos suaves (Web Audio, sin archivos): clics de ruido filtrado + tonos para éxito/error */
let AC,NB;
function tn(f,d,v,w=0){
  const t0=AC.currentTime+w,o=AC.createOscillator(),g=AC.createGain();
  o.frequency.setValueAtTime(f,t0);o.frequency.exponentialRampToValueAtTime(f*.85,t0+d);
  g.gain.setValueAtTime(0,t0);g.gain.linearRampToValueAtTime(v,t0+.006);g.gain.exponentialRampToValueAtTime(.0001,t0+d);
  o.connect(g).connect(AC.destination);o.start(t0);o.stop(t0+d+.02);
}
function clk(f,d,v){
  if(!NB){NB=AC.createBuffer(1,AC.sampleRate*.05,AC.sampleRate);NB.getChannelData(0).forEach((_,i,a)=>a[i]=Math.random()*2-1)}
  const t0=AC.currentTime,s=AC.createBufferSource(),b=AC.createBiquadFilter(),g=AC.createGain();
  s.buffer=NB;b.type='bandpass';b.frequency.value=f;b.Q.value=1.5;
  g.gain.setValueAtTime(v,t0);g.gain.exponentialRampToValueAtTime(.0001,t0+d);
  s.connect(b).connect(g).connect(AC.destination);s.start(t0);s.stop(t0+d+.01);
}
const SND={tap:()=>{clk(2400,.02,.6);tn(190,.03,.05)},key:()=>clk(3200,.014,.4),tab:()=>{clk(1700,.028,.7);tn(150,.04,.06)},ok:()=>{tn(660,.1,.06);tn(880,.16,.06,.09)},err:()=>tn(220,.14,.06)};
function snd(t){
  try{
    AC=AC||new(window.AudioContext||window.webkitAudioContext)();
    if(AC.state==='suspended')AC.resume();
    SND[t]();
  }catch(e){}
}
addEventListener('click',e=>{
  const b=e.target.closest('button,.card,a');if(!b)return;
  if(b.closest('#keys')){if(!b.classList.contains('ok'))snd('key')}
  else snd(b.classList.contains('tab')?'tab':'tap');
},true);

/* ---------- Charts: Expenses/Income por mes, donut + lista por categoría ---------- */
let cy=year,cm=month,ck=0,tgt='home';
const CY=()=>tgt==='charts'?cy:year,CM=()=>tgt==='charts'?cm:month;
const MES=['ene','feb','mar','abr','may','jun','jul','ago','sept','oct','nov','dic'];
const CHP=['#e0c35a','#3fa8c9','#e0708a','#8f7bd6','#6fcf97','#f2994a','#56ccf2','#bb6bd9'];
const CT=$('#ctabs'),CPG=$('#cpg'),CDS=[...document.querySelectorAll('#cdots .ch-d')],CSB=[...document.querySelectorAll('#cseg button')];
const pct=(v,t)=>{const p=Math.floor(v/t*10000)/100;return p>=100?'100%':p.toFixed(2)+'%'};

function chData(){
  const mt=TX.filter(t=>t.d.startsWith(`${cy}-${pad(cm+1)}`)&&(ck?t.a>0:t.a<0)),m={};
  mt.forEach(t=>m[t.c]=r2((m[t.c]||0)+Math.abs(t.a)));
  const items=Object.entries(m).map(([c,v])=>({c,v})).sort((a,b)=>b.v-a.v);
  return{items,total:r2(items.reduce((s,x)=>s+x.v,0))};
}
function chDonut(items,total){
  const R=66.5,C=80,W=26;let acc=0,seg='',sep='';
  if(!items.length)return`<svg class="ch-donut" viewBox="0 0 160 160"><circle cx="${C}" cy="${C}" r="${R}" stroke="#262626" stroke-width="${W}"/></svg>`;
  items.forEach((it,i)=>{
    const p=it.v/total*100;
    seg+=`<circle cx="${C}" cy="${C}" r="${R}" stroke="${CHP[i%CHP.length]}" stroke-width="${W}" pathLength="100" stroke-dasharray="${p} ${100-p}" stroke-dashoffset="${-acc}"/>`;
    if(items.length>1){const a=acc/100*2*Math.PI,c=Math.cos(a),s=Math.sin(a);
      sep+=`<line x1="${C+(R-W/2)*c}" y1="${C+(R-W/2)*s}" x2="${C+(R+W/2)*c}" y2="${C+(R+W/2)*s}"/>`}
    acc+=p;
  });
  return`<svg class="ch-donut" viewBox="0 0 160 160"><defs><mask id="chm" maskUnits="userSpaceOnUse" x="0" y="0" width="160" height="160"><g transform="rotate(-90 80 80)"><circle class="ch-sw" cx="80" cy="80" r="66.5" stroke="#fff" stroke-width="32" pathLength="100"/></g></mask></defs><g mask="url(#chm)"><g transform="rotate(-90 80 80)">${seg}<g stroke="#fff" stroke-width="1.6">${sep}</g></g></g></svg>`;
}
function chRender(){
  const{items,total}=chData(),max=items[0]?items[0].v:1;
  const hasHistory=drawExtraCharts();
  $('#cbody').classList.toggle('ch-none',!items.length&&!hasHistory);

  if(!items.length){$('#cp1').innerHTML='<div class="ch-soon">'+_('No records')+'</div>';$('#clist').innerHTML='<div class="ch-empty"><svg viewBox="0 0 24 24"><path d="M7 3h11a2 2 0 0 1 2 2v13a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3v-1h3V5a2 2 0 0 1 1-2zM10 9h5M10 13h5M16 6v1.5M18 6v1.5"/></svg><b>'+_('No hay registros')+'</b></div>';return}
  $('#cp1').innerHTML=`<div class="ch-dw">${chDonut(items,total)}<b id="ch-tot">0.00</b></div><ul class="ch-lg${items.length>5?' sc':''}">${items.map((x,i)=>`<li style="--i:${Math.min(i,14)}"><i class="ch-dot" style="--c:${CHP[i%CHP.length]}"></i><span class="ch-n">${escapeHTML(CATS[x.c].n)}</span><b>${pct(x.v,total)}</b></li>`).join('')}</ul>`;
  $('#clist').innerHTML=items.length?items.map((x,i)=>{const c=CATS[x.c];
    return`<div class="ch-row" style="--i:${Math.min(i,14)};--a:${c.a};--b:${c.b}"><span class="ic"><svg viewBox="0 0 24 24">${A[x.c]||A.others}</svg></span><div class="ch-rc"><div class="ch-rt"><span class="nm">${escapeHTML(c.n)}</span><span class="am">${fm(x.v)}</span></div><div class="ch-rb"><i style="--w:${(x.v/max).toFixed(4)}"></i><small>${pct(x.v,total)}</small></div></div></div>`}).join('')
    :`<div class="empty"><svg viewBox="0 0 24 24">${I.salary}</svg><b>${_(ck?'No income yet':'No expenses yet')}</b><span>${_('Nothing recorded in')} ${MONTHS[cm]} ${cy}</span></div>`;
  shown.c=0;tween($('#ch-tot'),'c',total);
}

/* Tabs de mes con subrayado que se desliza */
function chTabs(){
  CT.querySelectorAll('.ch-tab').forEach(t=>t.remove());
  CT.insertAdjacentHTML('afterbegin',MONTHS.slice(0,cy<TY?12:cy===TY?TM+1:0).map((n,i)=>`<button class="ch-tab" data-m="${i}">${MES[i]} ${cy}</button>`).join(''));
  chTabSel(false);
}
function chTabSel(sm){
  [...CT.querySelectorAll('.ch-tab')].forEach((t,i)=>t.classList.toggle('on',i===cm));
  $('#cind').style.setProperty('--i',cm);
  const w=CT.clientWidth/4,f=Math.round(CT.scrollLeft/w),b=sm&&!RM?'smooth':'auto';
  if(cm<f)CT.scrollTo({left:cm*w,behavior:b});else if(cm>f+3)CT.scrollTo({left:(cm-3)*w,behavior:b});
}
/* Paginador (puntos) */
function chDots(i){CDS.forEach((d,j)=>d.classList.toggle('on',j===i))}
function chPg(i,sm){CPG.scrollTo({left:i*CPG.clientWidth,behavior:sm&&!RM?'smooth':'auto'});chDots(i)}
CPG.addEventListener('scroll',()=>chDots(Math.round(CPG.scrollLeft/CPG.clientWidth)),{passive:true});
CDS.forEach((d,i)=>d.onclick=()=>chPg(i,true));

/* Cambios: igual que Home, el contenido sale, se redibuja y entra con sus animaciones */
function chSwap(){const b=$('#cbody');b.classList.add('out');setTimeout(()=>{b.scrollTop=0;chRender();b.classList.remove('out')},RM?0:180)}
function chGo(y,m){
  if(y===cy&&m===cm)return;
  const yc=y!==cy;cy=y;cm=m;
  if(yc)chTabs();else chTabSel(true);
  chSwap();
}
function chShow(){chTabs();chPg(0);$('#cbody').scrollTop=0;chRender()}
CT.onclick=e=>{const t=e.target.closest('.ch-tab');if(t)chGo(cy,+t.dataset.m)};
CSB.forEach((b,i)=>b.onclick=()=>{if(i===ck)return;ck=i;$('#cseg').style.setProperty('--s',i);CSB.forEach((x,j)=>x.classList.toggle('on',j===i));chSwap()});
$('#ccal').onclick=()=>{tgt='charts';sheet(true)};

/* AI Assistant: se abre con el reveal circular desde #aibtn (igual que Add desde el +).
   Aquí conectas la lógica real: AXP = campo de texto, #ax-send = enviar. */
const AX=$('#ax'),AXP=$('#ax-prompt'),AXB=$('#ax-box');
function openAI(){AX.inert=false;AX.querySelector('.ax-m').scrollTop=0;AX.classList.add('on')}
function closeAI(){AX.classList.remove('on');AX.inert=true;AXP.blur()}
function axSync(){AXB.classList.toggle('has',!!AXP.value.trim())}
$('#aibtn').onclick=openAI;
$('#ax-back').onclick=closeAI;
AXP.oninput=axSync;
document.querySelectorAll('.ax-sg').forEach(b=>b.onclick=()=>{AXP.value=b.querySelector('.ax-q').textContent;axSync();AXP.focus({preventScroll:true})});

/* ===== Idiomas + Perfil (apodo / idioma) ===== */
const LG=[['es','Español','es'],['en','English','en-US'],['fr','Français','fr'],['ru','Русский','ru'],['zh','中文','zh-CN'],['pt','Português','pt-BR']],LK=['en','es','fr','ru','zh','pt'];
/* Diccionario: inglés | es | fr | ru | zh | pt   (agrega filas para traducir más textos) */
const D=Object.fromEntries(`Home@nav|Inicio|Accueil|Главная|首页|Início
Charts|Gráficos|Graphiques|Графики|图表|Gráficos
Reports|Informes|Rapports|Отчёты|报告|Relatórios
Me|Yo|Moi|Я|我的|Eu
Expenses|Gastos|Dépenses|Расходы|支出|Despesas
Income|Ingresos|Revenus|Доходы|收入|Receitas
Balance|Balance|Solde|Баланс|结余|Saldo
Menu|Menú|Menu|Меню|菜单|Menu
AI Assistant|Asistente IA|Assistant IA|ИИ-помощник|AI 助手|Assistente de IA
Choose month|Elegir mes|Choisir le mois|Выбрать месяц|选择月份|Escolher mês
Coming soon|En preparación|Bientôt disponible|Скоро|敬请期待|Em breve
No records|Sin registros|Aucun enregistrement|Нет записей|暂无记录|Sem registros
Analytics|Análisis|Analyses|Аналитика|分析|Análises
Accounts|Cuentas|Comptes|Счета|账户|Contas
Monthly Statistics -|Estadísticas del mes -|Statistiques du mois -|Статистика за месяц -|月度统计 -|Estatísticas do mês -
Monthly Budget|Presupuesto mensual|Budget mensuel|Бюджет на месяц|月度预算|Orçamento mensal
Budget :|Presupuesto :|Budget :|Бюджет :|预算：|Orçamento :
Expenses :|Gastos :|Dépenses :|Расходы :|支出：|Despesas :
Remaining :|Restante :|Restant :|Остаток :|剩余：|Restante :
Budget Settings|Ajustes de presupuesto|Réglages du budget|Настройки бюджета|预算设置|Config. do orçamento
Net Worth|Patrimonio neto|Valeur nette|Чистый капитал|净资产|Patrimônio líquido
Assets|Activos|Actifs|Активы|资产|Ativos
Liabilities|Pasivos|Passifs|Обязательства|负债|Passivos
Add Account|Añadir cuenta|Ajouter un compte|Добавить счёт|添加账户|Adicionar conta
Manage Accounts|Gestionar cuentas|Gérer les comptes|Управление счетами|管理账户|Gerenciar contas
How to use accounts|Cómo usar las cuentas|Comment utiliser les comptes|Как пользоваться счетами|如何使用账户|Como usar as contas
Guest|Invitado|Invité|Гость|访客|Convidado
Data stored on this device|Datos guardados en este dispositivo|Données stockées sur cet appareil|Данные хранятся на этом устройстве|数据保存在此设备上|Dados salvos neste dispositivo
Transactions|Movimientos|Transactions|Операции|交易|Transações
Active days|Días activos|Jours actifs|Активные дни|活跃天数|Dias ativos
Categories|Categorías|Catégories|Категории|分类|Categorias
Currency|Moneda|Devise|Валюта|货币|Moeda
Monthly budget|Presupuesto mensual|Budget mensuel|Месячный бюджет|月预算|Orçamento mensal
Reminders|Recordatorios|Rappels|Напоминания|提醒|Lembretes
Icon|Icono|Icône|Иконки|图标|Ícone
Export data|Exportar datos|Exporter les données|Экспорт данных|导出数据|Exportar dados
Backup & restore|Copia y restauración|Sauvegarde et restauration|Резервная копия|备份与恢复|Backup e restauração
About|Acerca de|À propos|О приложении|关于|Sobre
Icon Style|Estilo de iconos|Style des icônes|Стиль иконок|图标样式|Estilo dos ícones
Add page icon styles|Iconos en la pantalla Añadir|Icônes de la page Ajouter|Иконки на странице добавления|添加页图标样式|Ícones da página Adicionar
Monochrome icons|Iconos monocromos|Icônes monochromes|Монохромные иконки|单色图标|Ícones monocromáticos
Colorful icons|Iconos de colores|Icônes colorées|Цветные иконки|彩色图标|Ícones coloridos
Cancel|Cancelar|Annuler|Отмена|取消|Cancelar
Add|Añadir|Ajouter|Добавить|添加|Adicionar
Expense|Gasto|Dépense|Расход|支出|Despesa
Transfer|Transferencia|Virement|Перевод|转账|Transferência
Select|Seleccionar|Sélectionner|Выбрать|选择|Selecionar
AI Toolbar|Herramientas IA|Outils IA|ИИ-инструменты|AI 工具栏|Ferramentas de IA
Note :|Nota :|Note :|Заметка :|备注：|Nota :
Enter a note...|Escribe una nota...|Saisir une note...|Введите заметку...|输入备注...|Digite uma nota...
Today|Hoy|Aujourd’hui|Сегодня|今天|Hoje
Calendar|Calendario|Calendrier|Календарь|日历|Calendário
Add category|Añadir categoría|Ajouter une catégorie|Добавить категорию|添加分类|Adicionar categoria
Enter category name...|Nombre de la categoría...|Nom de la catégorie...|Название категории...|输入分类名称...|Nome da categoria...
Enter an amount|Ingresa un monto|Saisissez un montant|Введите сумму|请输入金额|Digite um valor
Saved|Guardado|Enregistré|Сохранено|已保存|Salvo
Enter a name|Ingresa un nombre|Saisissez un nom|Введите название|请输入名称|Digite um nome
Category added|Categoría añadida|Catégorie ajoutée|Категория добавлена|已添加分类|Categoria adicionada
New account|Nueva cuenta|Nouveau compte|Новый счёт|新账户|Nova conta
Help|Ayuda|Aide|Справка|帮助|Ajuda
Budget|Presupuesto|Budget|Бюджет|预算|Orçamento
Date|Fecha|Date|Дата|日期|Data
Photo|Foto|Photo|Фото|照片|Foto
Voice|Voz|Voix|Голос|语音|Voz
Clear chat|Limpiar chat|Effacer le chat|Очистить чат|清空对话|Limpar chat
Recurring|Recurrentes|Récurrents|Повторяющиеся|定期|Recorrentes
Assistant|Asistente|Assistant|Помощник|助手|Assistente
Close|Cerrar|Fermer|Закрыть|关闭|Fechar
Back|Atrás|Retour|Назад|返回|Voltar
Save|Guardar|Enregistrer|Сохранить|保存|Salvar
Search|Buscar|Rechercher|Поиск|搜索|Buscar
Hi! I can help analyze spending, look up transactions, and answer how-to questions.|¡Hola! Puedo ayudarte a analizar tus gastos, buscar movimientos y resolver dudas de uso.|Salut ! Je peux analyser vos dépenses, retrouver des transactions et répondre à vos questions.|Привет! Помогу проанализировать расходы, найти операции и ответить на вопросы по приложению.|你好！我可以帮你分析支出、查找交易，并解答使用问题。|Olá! Posso ajudar a analisar gastos, buscar transações e tirar dúvidas de uso.
Try asking|Prueba a preguntar|Essayez de demander|Попробуйте спросить|试试这样问|Experimente perguntar
How much did I spend this month?|¿Cuánto gasté este mes?|Combien ai-je dépensé ce mois-ci ?|Сколько я потратил в этом месяце?|这个月我花了多少钱？|Quanto gastei este mês?
What percentage of my spending is dining?|¿Qué porcentaje de mis gastos es comida fuera?|Quelle part de mes dépenses va aux restaurants ?|Какую долю расходов составляют рестораны?|我的支出中餐饮占多少比例？|Qual porcentagem dos meus gastos é com refeições fora?
How much budget is left?|¿Cuánto presupuesto me queda?|Combien reste-t-il de budget ?|Сколько бюджета осталось?|预算还剩多少？|Quanto orçamento ainda resta?
How do I set a budget?|¿Cómo establezco un presupuesto?|Comment définir un budget ?|Как задать бюджет?|如何设置预算？|Como defino um orçamento?
Ask about your finances or how to use the app…|Pregunta sobre tus finanzas o el uso de la app…|Posez une question sur vos finances ou l’app…|Спросите о финансах или о работе приложения…|询问财务问题或应用用法…|Pergunte sobre suas finanças ou o app…
Nickname|Apodo|Surnom|Псевдоним|昵称|Apelido
Language|Idioma|Langue|Язык|语言|Idioma
Name or nickname|Nombre o apodo|Nom ou surnom|Имя или псевдоним|名字或昵称|Nome ou apelido
Enter a nickname...|Escribe tu apodo...|Saisissez votre surnom...|Введите псевдоним...|输入昵称...|Digite seu apelido...
No results|Sin resultados|Aucun résultat|Нет результатов|无结果|Sem resultados
Try another category or amount|Prueba otra categoría o monto|Essayez une autre catégorie ou un autre montant|Попробуйте другую категорию или сумму|试试其他分类或金额|Tente outra categoria ou valor
No transactions yet|Aún no hay movimientos|Aucune transaction pour l’instant|Операций пока нет|暂无交易|Nenhuma transação ainda
Nothing recorded in|Nada registrado en|Rien d’enregistré en|Нет записей за|没有记录：|Nada registrado em
No transactions|Sin movimientos|Aucune transaction|Нет операций|无交易|Sem transações
Tap + to add one|Toca + para añadir uno|Appuyez sur + pour en ajouter|Нажмите +, чтобы добавить|点按 + 添加|Toque em + para adicionar
No income yet|Aún no hay ingresos|Aucun revenu pour l’instant|Доходов пока нет|暂无收入|Nenhuma receita ainda
No expenses yet|Aún no hay gastos|Aucune dépense pour l’instant|Расходов пока нет|暂无支出|Nenhuma despesa ainda
Food|Comida|Alimentation|Еда|餐饮|Alimentação
Education|Educación|Éducation|Образование|教育|Educação
Transportation|Transporte|Transport|Транспорт|交通|Transporte
Salary|Salario|Salaire|Зарплата|工资|Salário
Haircut|Corte de pelo|Coiffeur|Стрижка|理发|Cabeleireiro
Shopping|Compras|Shopping|Покупки|购物|Compras
Phone|Teléfono|Téléphone|Телефон|电话|Telefone
Entertainment|Ocio|Loisirs|Развлечения|娱乐|Lazer
Beauty|Belleza|Beauté|Красота|美容|Beleza
Sports|Deportes|Sport|Спорт|运动|Esportes
Social|Social|Social|Общение|社交|Social
Clothing|Ropa|Vêtements|Одежда|服饰|Roupas
Car|Auto|Voiture|Авто|汽车|Carro
Alcohol|Alcohol|Alcool|Алкоголь|酒类|Álcool
Cigarettes|Cigarrillos|Cigarettes|Сигареты|香烟|Cigarros
Electronics|Electrónica|Électronique|Электроника|电子产品|Eletrônicos
Travel|Viajes|Voyages|Путешествия|旅行|Viagens
Health|Salud|Santé|Здоровье|健康|Saúde
Pets|Mascotas|Animaux|Питомцы|宠物|Pets
Repairs|Reparaciones|Réparations|Ремонт|维修|Reparos
Housing|Vivienda|Logement|Жильё|住房|Moradia
Home|Hogar|Maison|Дом|家居|Casa
Gifts|Regalos|Cadeaux|Подарки|礼物|Presentes
Donations|Donaciones|Dons|Пожертвования|捐赠|Doações
Lottery|Lotería|Loterie|Лотерея|彩票|Loteria
Snacks|Snacks|Snacks|Перекусы|零食|Lanches
Kids|Niños|Enfants|Дети|儿童|Crianças
Vegetables|Verduras|Légumes|Овощи|蔬菜|Vegetais
Fruits|Frutas|Fruits|Фрукты|水果|Frutas
Investments|Inversiones|Investissements|Инвестиции|投资|Investimentos
Part-Time|Medio tiempo|Temps partiel|Подработка|兼职|Meio período
Bonus|Bono|Prime|Премия|奖金|Bônus
Others|Otros|Autres|Другое|其他|Outros
Settings|Ajustes|Réglages|Настройки|设置|Ajustes`.split('\n').map(r=>{const a=r.split('|');return[a[0].toLowerCase(),a.slice(1)]}));
/* Textos originales en español del HTML → clave en inglés */
const SRC={Inicio:'Home@nav',Gráficos:'Charts',Informes:'Reports',Yo:'Me',Gastos:'Expenses',Ingresos:'Income','En preparación':'Coming soon','No hay registros':'No records',Cerrar:'Close',Añadir:'Add',Menú:'Menu','Nueva cuenta':'New account',Ayuda:'Help',Presupuesto:'Budget','Gestionar cuentas':'Manage Accounts',Fecha:'Date',Foto:'Photo',Voz:'Voice','Limpiar chat':'Clear chat','Movimientos recurrentes':'Recurring',Moneda:'Currency',Asistente:'Assistant'};
let LANG=(()=>{try{return localStorage.getItem('mt-lang')}catch(e){return null}})(),LI=1,LOC='es',NAME=(()=>{try{return localStorage.getItem('mt-name')||''}catch(e){return ''}})();
if(!LG.some(g=>g[0]===LANG))LANG='es';
const _=s=>{const e=SRC[s]||s,r=D[e.toLowerCase()];return LI&&r?r[LI-1]:e.split('@')[0]};
const _t=s=>_(s);

Object.values(CATS).forEach(c=>{const o=c.n;Object.defineProperty(c,'n',{get:()=>_(o),enumerable:true,configurable:true})});

const SKIP='#list,#cdh,#cdl,#clist,#cp1,#ctabs,#toast,#months,#cldw,#clml,#pm,#pyr,#amt,#s-cur,#pv-cu,#fab,.me b,.k.td,#n-ics';
function walk(){
  const w=document.createTreeWalker($('#app'),NodeFilter.SHOW_TEXT);let n;
  while(n=w.nextNode()){
    const p=n.parentElement;if(!p||p.closest(SKIP)||/^(SCRIPT|STYLE)$/.test(p.tagName))continue;
    const raw=n._o??=n.nodeValue,k=raw.trim();if(k)n.nodeValue=raw.replace(k,_(k));
  }
  document.querySelectorAll('#app [aria-label],#app [placeholder]').forEach(el=>{
    if(el.closest(SKIP))return;const o=el._oa??={};
    ['aria-label','placeholder'].forEach(a=>{if(el.hasAttribute(a)){o[a]??=el.getAttribute(a);el.setAttribute(a,_(o[a]))}});
  });
}
function monthsFor(){
  const f=new Intl.DateTimeFormat(LOC,{month:'short'}),m=Array.from({length:12},(x,i)=>{const s=f.format(new Date(2026,i,15)).replace('.','');return s.charAt(0).toUpperCase()+s.slice(1)});
  MONTHS.splice(0,12,...m);MES.splice(0,12,...m.map(s=>s.toLowerCase()));
}
function tdl(){let lab=_('Today');if(addDate){const d=new Date(addDate+'T00:00');lab=`${MONTHS[d.getMonth()]} ${d.getDate()}`}$('.k.td').innerHTML=KI.t.replace('Today',lab)}
const MEB=$('.me b'),AVL=$('.av');
function renderMe(){const n=NAME||_('Guest');MEB.textContent=n;AVL.textContent=[...n.trim()][0].toUpperCase();$('#pv-nm').textContent=NAME}
function setLang(l,init){
  LANG=l;LI=LK.indexOf(l);LOC=LG.find(g=>g[0]===l)[2];document.documentElement.lang=l;
  monthsFor();walk();
  $('#cldw').innerHTML=Array.from({length:7},(x,i)=>`<span style="--i:${i}">${new Date(2023,0,1+i).toLocaleDateString(LOC,{weekday:'short'})}</span>`).join('');
  $('#pm').textContent=MONTHS[month];$('#clml').textContent=`${MONTHS[month]} ${year}`;
  $('#fab').setAttribute('aria-label',_($('#add').classList.contains('on')?'Cerrar':'Añadir'));
  tdl();renderMe();curList();$('#pv-lg').textContent=LG.find(g=>g[0]===l)[1];
  document.querySelectorAll('#s-lang button').forEach(b=>b.classList.toggle('on',b.dataset.l===l));
  if(!init){rebuildCategories();grid();chTabs();render(false);chRender();if(calOn)detail(false)}
}

/* ===== Moneda (solo etiqueta/símbolo; no convierte valores) ===== */
const CURS={PEN:'S/',USD:'$',EUR:'€',CNY:'¥',RUB:'₽',GBP:'£',JPY:'JP¥',BRL:'R$',MXN:'MX$',COP:'COL$',CLP:'CL$',ARS:'AR$',CAD:'CA$',CHF:'CHF'};
let CUR=(()=>{try{return localStorage.getItem('mt-cur')}catch(e){return null}})();if(!CURS[CUR])CUR='PEN';
const cs=()=>CURS[CUR];
function curList(){
  let dn;try{dn=new Intl.DisplayNames([LOC],{type:'currency'})}catch(e){}
  $('#s-cur').innerHTML=Object.keys(CURS).map(c=>{let n=c;try{n=dn.of(c)}catch(e){}n=n.charAt(0).toUpperCase()+n.slice(1);return `<button data-c="${c}"><span class="cb">${CURS[c]}</span><span class="cn">${n}<small>${c}</small></span>${CK}</button>`}).join('');
  setCur(CUR,true);
}
function setCur(c,init){
  CUR=c;
  document.querySelectorAll('#s-cur button').forEach(b=>b.classList.toggle('on',b.dataset.c===c));
  $('#pv-cu').textContent=`${CURS[c]} · ${c}`;$('#amt').dataset.c=CURS[c];
  if(!init){render(false);chRender();if(calOn){calTot();detail(false)}}
}

/* Pantallas Apodo e Idioma */
const sN=$('#sub-name'),sL=$('#sub-lang');
const subOpen=e=>{e.inert=false;e.classList.add('on')},subClose=e=>{e.classList.remove('on');e.inert=true;if(document.activeElement)document.activeElement.blur()};
sN.querySelector('.ib').onclick=()=>subClose(sN);sL.querySelector('.ib').onclick=()=>subClose(sL);
$('#pnm').onclick=()=>{$('#nm-in').value=NAME;subOpen(sN);setTimeout(()=>$('#nm-in').focus({preventScroll:true}),RM?0:420)};
function nmSave(){NAME=$('#nm-in').value.trim().slice(0,24);saveSettings();renderMe();snd('ok');subClose(sN);toast('Saved')}
$('#nm-ok').onclick=nmSave;
$('#nm-in').onkeydown=e=>{if(e.key==='Enter')nmSave()};
$('#s-lang').innerHTML=LG.map(([k,n])=>`<button data-l="${k}"><span>${n}</span>${CK}</button>`).join('');
$('#s-lang').onclick=e=>{const b=e.target.closest('button');if(b){setLang(b.dataset.l);saveSettings();subClose(sL)}};
$('#pln').onclick=()=>subOpen(sL);
const sC=$('#sub-cur');sC.querySelector('.ib').onclick=()=>subClose(sC);
$('#pv-cu').parentElement.onclick=()=>subOpen(sC);
$('#s-cur').onclick=e=>{const b=e.target.closest('button');if(b)selectCurrency(b.dataset.c)};


/* Conecta las pantallas originales al registro local. */
const transferTiles = [...document.querySelectorAll('.tc')];
const transferIcon = '<path d="M4 8h16l-4-4M20 16H4l4 4"/>';
A.transfer = transferIcon;
CATS.transfer = { get n(){return _('Transfer')}, a:'#6ab7ff', b:'#cfe6ff' };
const builtIns = [
  ...XC.filter(([,id])=>id!=='plus').map(([name,id])=>({id,name,type:'expense'})),
  ...IN.filter(([,id])=>id!=='plus').map(([name,id])=>({id,name,type:'income'}))
].map(category=>({...category,icon:'grid',color:'#ffd93d',archived:false,original:true}));
let ledger, saving = false, sheetSubmit = null, sheetReturn = null;
let draft = {}, selecting = 'account', chat = [];

const safe = escapeHTML;
const format = cents => new Intl.NumberFormat(LOC,{minimumFractionDigits:2,maximumFractionDigits:2}).format(cents/100);
const price = cents => (cents<0?'−':'')+cs()+' '+format(Math.abs(cents));
const activeMonth = () => year+'-'+pad(month+1);
const currentAccount = id => ledger.accounts.find(account=>account.id===id);
const accountLabel = id => currentAccount(id)?.name || _('Select');
const fail = message => { throw new Error(message); };
const requireValue = (value,message) => { if(!value)fail(message); };
const on = (id,fn) => { $(id).onclick = event=>Promise.resolve().then(()=>fn(event)).catch(error=>toast(error.message)); };
const action = (label,id) => '<button type="button" class="nmb" id="'+id+'">'+safe(label)+'</button>';
const field = (label,name,value='',type='text',extra='') => '<label class="local-field">'+safe(label)+'<input name="'+name+'" type="'+type+'" value="'+safe(value)+'" '+extra+'></label>';
const choices = (label,name,options,value='') => '<label class="local-field">'+safe(label)+'<select name="'+name+'">'+options.map(([id,title])=>'<option value="'+safe(id)+'"'+(id===value?' selected':'')+'>'+safe(title)+'</option>').join('')+'</select></label>';
const form = (content,label=_('Save')) => '<form class="local-form">'+content+'<button class="nmb" type="submit">'+safe(label)+'</button></form>';

function panel(title,content,submit=null) {
  const layer = $('#local-sheet');
  $('#local-body').onclick = null;
  if(layer.inert) sheetReturn = document.activeElement;
  $('#local-title').textContent = title;
  $('#local-body').innerHTML = content;
  $('#local-body').scrollTop = 0;
  sheetSubmit = submit;
  layer.inert = false;
  layer.classList.add('on');
  $('#local-back').focus({preventScroll:true});
}
function closePanel() {
  subClose($('#local-sheet'));
  sheetSubmit = null;
  sheetReturn?.focus?.({preventScroll:true});
}
on('#local-back',closePanel);
$('#local-body').onsubmit = async event => {
  event.preventDefault();
  if(!sheetSubmit||saving) return;
  const button = event.submitter;
  if(button) button.disabled = true;
  try { await sheetSubmit(new FormData(event.target)); }
  catch(error) { toast(error.message); }
  finally { if(button) button.disabled = false; }
};

function rebuildCategories() {
  for(const c of ledger.categories) {
    const existing = CATS[c.id];
    if(c.original && existing) continue;
    const [group,index] = String(c.originalIcon||'').split('-').map(Number);
    const glyph = NI[group]?.[1]?.[index] || A[c.id] || A.others;
    A[c.id] = glyph;
    const color = /^#[0-9a-f]{6}$/i.test(c.originalColor||'') ? c.originalColor : c.color;
    CATS[c.id] = { n:c.name,a:color,b:lt(color) };
  }
  for(const [type,selector] of [['expense','#pe'],['income','#pi']]) {
    const categories = ledger.categories.filter(c=>c.type===type&&!c.archived);
    $(selector).innerHTML = categories.map((c,i)=>{
      const {a,b,n} = CATS[c.id];
      return '<button class="ct cl" style="--i:'+i+';--a:'+a+';--b:'+b+'" data-k="'+c.id+'"><span class="c"><svg viewBox="0 0 24 24">'+A[c.id]+'</svg></span>'+safe(n)+'</button>';
    }).join('')+tile([type==='income'?_('Settings'):'','plus'],categories.length);
    $(selector).querySelectorAll('.ct').forEach(button=>button.onclick=()=>pick(button));
  }
}

function syncTransactions() {
  TX.splice(0,TX.length,...ledger.transactions.slice().reverse().map(entry=>({
    ...entry,d:entry.date,n:entry.note,c:entry.type==='transfer'?'transfer':entry.category,
    a:entry.type==='transfer'?0:(entry.type==='income'?1:-1)*entry.amount/100
  })));
}
function refresh() {
  syncTransactions();
  render(false);
  if($('#v-charts').classList.contains('on')) chRender();
  if(calOn) {
    const replacement = buildGrid(year,month);
    cg?.replaceWith(replacement);
    cg = replacement;
    ring(cg,selD,true);
    calTot();
    detail(false);
  }
}
async function commit(update,{categories=false,repaint=true}={}) {
  if(saving) fail('Espera a que termine el guardado.');
  saving = true;
  try {
    const next = structuredClone(ledger);
    update(next);
    await persist(next,ledger.revision);
    ledger = next;
    if(categories) rebuildCategories();
    if(repaint) refresh();
  } finally { saving = false; }
}
function saveSettings() {
  commit(next=>{
    Object.assign(next.settings,{name:NAME,language:LANG,currency:CUR,iconStyle:ST.add,iconGradient:ST.ic});
  },{repaint:false}).catch(error=>{
    applySettings();
    toast(error.message);
  });
}
function applySettings() {
  const settings = ledger.settings;
  NAME = settings.name;
  CUR = settings.currency;
  ST.add = settings.iconStyle;
  ST.ic = settings.iconGradient==='solid'?'solid':'gradient';
  applyIc();
  setLang(settings.language,true);
  rebuildCategories();
}
function selectCurrency(currency) {
  const update = async () => {
    await commit(next=>{next.settings.currency=currency;},{repaint:false});
    setCur(currency);
    closePanel();
    subClose(sC);
  };
  if(currency===CUR) return subClose(sC);
  if(!ledger.transactions.length&&!ledger.accounts.some(a=>a.initial)) return update().catch(e=>toast(e.message));
  panel(_('Currency'),'<p class="local-note">El cambio de moneda conserva los importes. No se aplica un tipo de cambio.</p>'+action(_('Save'),'confirm-currency'));
  on('#confirm-currency',update);
}

function transactionRow(entry,index) {
  const c = CATS[entry.c];
  const caption = entry.type==='transfer' ? accountLabel(entry.account)+' → '+accountLabel(entry.to) : entry.note;
  const amount = (entry.type==='expense'?'−':entry.type==='income'?'+':'')+cs()+format(entry.amount);
  return '<button class="row local-row" data-entry="'+entry.id+'" style="--i:'+index+';--a:'+c.a+';--b:'+c.b+'"><span class="ic"><svg viewBox="0 0 24 24">'+A[entry.c]+'</svg></span><span class="nm">'+safe(c.n)+(caption?'<small>'+safe(caption)+'</small>':'')+'</span><span class="am">'+amount+'</span></button>';
}

function resetDraft() {
  draft = {account:ledger.accounts.find(a=>!a.archived).id,to:'',note:'',receipt:'',frequency:''};
  paintDraft();
}
function paintDraft() {
  const [origin,destination] = transferTiles;
  for(const [button,id] of [[origin,draft.account],[destination,draft.to]]) {
    const label = button.lastChild;
    label.textContent = accountLabel(id);
  }
  $('#acb').title = accountLabel(draft.account);
  $('#acb').setAttribute('aria-label',_('Account')+': '+accountLabel(draft.account));
  $('#cam').classList.toggle('attached',Boolean(draft.receipt));
  $('#rec').classList.toggle('attached',Boolean(draft.frequency));
}
function showTransferKeypad() {
  const add = $('#add');
  if(curSeg!==2||!draft.account||!draft.to) return;
  add.style.setProperty('--kh',$('#kp').offsetHeight+'px');
  add.classList.add('sel');
}
function openAccounts(which='account') {
  selecting = which;
  const existing = $('#acc .nor');
  if(existing) existing.remove();
  let list = $('#account-picker');
  if(!list) {
    list = document.createElement('div');
    list.id='account-picker';
    list.className='so local-picker';
    $('#acc').append(list);
  }
  list.innerHTML = ledger.accounts.filter(a=>!a.archived).map(a=>
    '<button data-account="'+a.id+'"><span>'+safe(a.name)+'</span><small>'+price(accountBalance(ledger,a.id))+'</small></button>'
  ).join('');
  list.onclick = event=>{
    const button = event.target.closest('[data-account]');
    if(!button) return;
    const id = button.dataset.account;
    if(curSeg===2 && id===draft[which==='account'?'to':'account']) return toast('Elige dos cuentas diferentes.');
    draft[which] = id;
    $('#add').classList.remove('aopen');
    paintDraft();
    showTransferKeypad();
  };
  $('#add').classList.add('aopen');
}
function accountForm(id='',fromPicker=false) {
  const account = currentAccount(id);
  panel(account?'Editar cuenta':_('New account'),form(
    field('Nombre','name',account?.name||'','text','required maxlength="40"')+
    field('Saldo inicial','initial',((account?.initial||0)/100).toFixed(2),'text','required inputmode="decimal"')+
    '<p class="local-note">Puedes usar un saldo inicial negativo para registrar una deuda.</p>'
  ),async data=>{
    const name = String(data.get('name')).trim();
    const initial = parseMoney(data.get('initial'),true);
    requireValue(name,'Escribe un nombre.');
    requireValue(!ledger.accounts.some(a=>a.id!==id&&a.name.toLowerCase()===name.toLowerCase()),'Ya existe una cuenta con ese nombre.');
    const key = id||uid();
    await commit(next=>{
      const record = next.accounts.find(a=>a.id===key);
      if(record) Object.assign(record,{name,initial});
      else next.accounts.push({id:key,name,initial,archived:false});
    });
    closePanel();
    if(fromPicker) openAccounts(selecting);
    toast('Saved');
  });
}
function manageAccounts() {
  panel(_('Manage Accounts'),'<div class="so">'+ledger.accounts.map(a=>
    '<button data-account="'+a.id+'"><span>'+safe(a.name)+'</span><small>'+price(accountBalance(ledger,a.id))+'</small></button>'
  ).join('')+'</div>'+action(_('New account'),'create-account'));
  $('#local-body').onclick = event=>{
    const button = event.target.closest('[data-account]');
    if(button) accountForm(button.dataset.account);
  };
  on('#create-account',()=>accountForm());
}

function datePicker() {
  panel(_('Date'),form(field(_('Date'),'date',addDate||today(),'date','required min="1900-01-01" max="2199-12-31"')),data=>{
    const date = String(data.get('date'));
    requireValue(validDate(date),'Elige una fecha válida.');
    addDate = date;
    tdl();
    closePanel();
  });
}
function receiptPicker() {
  panel('Comprobante','<p class="local-note">Elige una imagen para este movimiento.</p>'+
    (draft.receipt?'<img class="local-receipt" src="'+safe(draft.receipt)+'" alt="Comprobante">'+action('Quitar imagen','remove-receipt'):'')+
    '<input id="receipt-file" type="file" accept="image/*" aria-label="Elegir comprobante">');
  if(draft.receipt) on('#remove-receipt',()=>{draft.receipt='';paintDraft();closePanel();});
  $('#receipt-file').onchange = async event=>{
    const file = event.target.files[0];
    if(!file) return;
    try {
      requireValue(file.type.startsWith('image/') && file.size<=10000000,'Elige una imagen de hasta 10 MB.');
      const url = URL.createObjectURL(file);
      try {
        const image = new Image();
        image.src = url;
        await image.decode();
        const scale = Math.min(1,1000/Math.max(image.width,image.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1,Math.round(image.width*scale));
        canvas.height = Math.max(1,Math.round(image.height*scale));
        const ctx = canvas.getContext('2d');
        ctx.fillStyle='#fff';
        ctx.fillRect(0,0,canvas.width,canvas.height);
        ctx.drawImage(image,0,0,canvas.width,canvas.height);
        const receipt = canvas.toDataURL('image/jpeg',.58);
        requireValue(receipt.length<=400000,'La imagen es demasiado grande.');
        if($('#receipt-file')!==event.target) return;
        draft.receipt = receipt;
        paintDraft();
        closePanel();
      } finally { URL.revokeObjectURL(url); }
    } catch(error) { toast(error.message); }
  };
}
function recurrenceChoice() {
  panel('Repetir movimiento',form(choices('Frecuencia','frequency',[
    ['','Una vez'],['weekly','Semanal'],['monthly','Mensual'],['yearly','Anual']
  ],draft.frequency)),data=>{
    draft.frequency = String(data.get('frequency'));
    paintDraft();
    closePanel();
  });
}
async function saveMovement() {
  if(saving) return;
  const amount = calc();
  requireValue(amount>0,_('Enter an amount'));
  const type = ['expense','income','transfer'][curSeg];
  const date = addDate||today();
  const input = {id:draft.id,type,amount,date,account:draft.account,to:draft.to,category:cat||'',note:$('#nt').value.trim(),receipt:draft.receipt};
  await commit(next=>{
    const entry = putTransaction(next,input);
    if(!draft.id&&draft.frequency) next.recurring.push({
      ...entry,id:uid(),receipt:'',frequency:draft.frequency,
      day:Number(date.slice(8)),nextDate:nextOccurrence(date,draft.frequency),active:true
    });
  },{repaint:false});
  syncTransactions();
  const [y,m,d] = date.split('-').map(Number);
  snd('ok');
  setAdd(false);
  if(calOn) setTimeout(()=>{calAfter(y,m-1,d);toast('Saved');},450);
  else {show(0);go(y,m-1);toast('Saved');}
}
function editMovement(id) {
  const entry = ledger.transactions.find(t=>t.id===id);
  if(!entry) return;
  panel('Movimiento','<p class="local-note">'+safe(CATS[entry.type==='transfer'?'transfer':entry.category].n)+' · '+price(entry.amount)+'<br>'+safe(entry.date)+' · '+safe(accountLabel(entry.account))+(entry.to?' → '+safe(accountLabel(entry.to)):'')+(entry.note?'<br>'+safe(entry.note):'')+'</p>'+
    (entry.receipt?'<img class="local-receipt" src="'+safe(entry.receipt)+'" alt="Comprobante">':'')+
    action('Editar','edit-entry')+action('Eliminar','remove-entry'));
  on('#edit-entry',()=>{
    closePanel();
    openAdd(entry.date);
    segSet(['expense','income','transfer'].indexOf(entry.type));
    if(entry.type!=='transfer') {
      let selected=document.querySelector('.pn.on [data-k="'+entry.category+'"]');
      if(!selected) {
        selected=document.createElement('button');
        selected.className='ct';
        selected.dataset.k=entry.category;
      }
      pick(selected);
    }
    draft = {...entry,frequency:''};
    ex=(entry.amount/100).toFixed(2);
    $('#nt').value=entry.note;
    show$();
    paintDraft();
    showTransferKeypad();
  });
  on('#remove-entry',()=>{
    panel('Eliminar movimiento','<p class="local-note">Se actualizarán el balance y los informes.</p>'+action('Confirmar eliminación','confirm-entry'));
    on('#confirm-entry',async ()=>{
      await commit(next=>{next.transactions=next.transactions.filter(t=>t.id!==id);});
      closePanel();
      toast('Movimiento eliminado');
    });
  });
}

async function saveCategory() {
  const name = $('#n-nm').value.trim();
  const type = NC.t?'income':'expense';
  requireValue(name,_('Enter a name'));
  requireValue(!ledger.categories.some(c=>c.type===type&&CATS[c.id]?.n.toLowerCase()===name.toLowerCase()),'Ya existe una categoría con ese nombre.');
  const id=uid();
  await commit(next=>{
    next.categories.push({id,name,type,icon:'grid',color:'#ffd93d',archived:false,originalColor:NC.c,originalIcon:NC.i});
  },{categories:true,repaint:false});
  ncClose();
  segSet(NC.t);
  pick(document.querySelector('.pn.on [data-k="'+id+'"]'));
  toast('Category added');
}

function drawExtraCharts() {
  const type = ck?'income':'expense';
  const key = cy+'-'+pad(cm+1);
  const values = Array.from({length:new Date(cy,cm+1,0).getDate()},()=>0);
  for(const entry of monthly(ledger,key).items) if(entry.type===type) values[Number(entry.date.slice(8))-1]+=entry.amount;
  const periods = Array.from({length:6},(_,i)=>{
    const d = new Date(cy,cm-5+i,1);
    return [MONTHS[d.getMonth()],monthly(ledger,localDate(d).slice(0,7))[type]];
  });
  function bars(title,items) {
    const max = Math.max(1,...items.map(([,value])=>value));
    return '<div class="local-plot"><h3>'+title+'</h3><div class="local-bars">'+items.map(([label,value])=>
      '<button type="button" title="'+safe(label+' · '+price(value))+'" data-point="'+safe(label+' · '+price(value))+'"><i style="height:'+Math.max(2,value/max*100)+'%"></i></button>'
    ).join('')+'</div><small>'+safe(items[0][0])+' — '+safe(items.at(-1)[0])+'</small></div>';
  }
  $('#cp2').innerHTML=bars('Por día',values.map((value,i)=>[String(i+1),value]));
  $('#cp3').innerHTML=bars('Últimos 6 meses',periods);
  return periods.some(([,amount])=>amount>0);
}
function updateReport() {
  const m = monthly(ledger,activeMonth());
  const values = ledger.accounts.map(a=>accountBalance(ledger,a.id));
  const assets = values.reduce((sum,n)=>sum+Math.max(0,n),0);
  const debt = values.reduce((sum,n)=>sum+Math.max(0,-n),0);
  $('#rbd .bl:first-child b').textContent=price(m.budget);
  $('#rbd .bl.r b').textContent=price(m.budget-m.expense);
  $('#rbd .ring b').textContent=m.budget?Math.round(m.expense/m.budget*100)+'%':'--';
  $('#ra .nw>b').textContent=price(assets-debt);
  const [assetsNode,debtNode]=$$('#ra .ab b');
  assetsNode.textContent=price(assets);
  debtNode.textContent=price(debt);
  $('#fc').textContent=new Set(ledger.transactions.filter(t=>t.category).map(t=>t.category)).size;
}
function $$(selector){return [...document.querySelectorAll(selector)];}
function budgetForm() {
  const key=activeMonth();
  panel(_('Monthly budget'),form('<p class="local-note">'+safe(MONTHS[month]+' '+year)+'</p>'+
    field('Presupuesto','amount',((ledger.budgets[key]||0)/100).toFixed(2),'text','required inputmode="decimal"')
  ),async data=>{
    const amount=parseMoney(data.get('amount'));
    await commit(next=>{if(amount) next.budgets[key]=amount;else delete next.budgets[key];});
    closePanel();
    toast('Saved');
  });
}
function recurrenceList() {
  const rules=ledger.recurring;
  panel('Movimientos recurrentes',rules.length?rules.map(rule=>{
    const due=rule.active&&rule.nextDate<=today();
    return '<div class="local-rule"><b>'+safe(rule.note||CATS[rule.category]?.n||_('Transfer'))+'</b><p>'+safe(rule.nextDate)+' · '+price(rule.amount)+'</p><div class="local-rule-actions">'+
      (due?'<button data-rule="'+rule.id+'" data-action="record">Registrar</button><button data-rule="'+rule.id+'" data-action="skip">Omitir</button>':'')+
      '<button data-rule="'+rule.id+'" data-action="pause">'+(rule.active?'Pausar':'Reanudar')+'</button><button data-rule="'+rule.id+'" data-action="remove">Eliminar</button></div></div>';
  }).join(''):'<p class="local-note">Para crear una repetición, toca el icono superior al añadir un movimiento.</p>');
  $('#local-body').onclick = async event=>{
    const button = event.target.closest('[data-rule]');
    if(!button||saving) return;
    const {rule,action:operation}=button.dataset;
    try {
      await commit(next=>{
        if(operation==='remove') next.recurring=next.recurring.filter(r=>r.id!==rule);
        else if(operation==='pause') {const r=next.recurring.find(r=>r.id===rule);r.active=!r.active;}
        else completeRecurring(next,rule,operation==='skip');
      });
      recurrenceList();
    } catch(error){toast(error.message);}
  };
}

function searchMovements() {
  panel('Buscar movimientos',form(field('Nota, categoría o importe','search',q,'search'),'Buscar'),data=>{
    q = String(data.get('search')).trim();
    closePanel();
    show(0);
    render(false);
  });
}
function menu() {
  panel(_('Menu'),'<div class="so"><button id="menu-search">Buscar movimientos</button><button id="menu-recurring">Movimientos recurrentes</button><button id="menu-accounts">'+_('Manage Accounts')+'</button>'+(q?'<button id="clear-search">Mostrar todos los movimientos</button>':'')+'</div>');
  on('#menu-search',searchMovements);
  on('#menu-recurring',recurrenceList);
  on('#menu-accounts',manageAccounts);
  if(q) on('#clear-search',()=>{q='';closePanel();show(0);render(false);});
}
function reminders() {
  if (!Capacitor.isNativePlatform()) {
    panel(_('Reminders'),form(
      '<p class="local-note">Abre el recordatorio descargado en tu calendario para recibir los avisos diarios.</p>'+
      field('Hora del recordatorio diario','time',ledger.settings.reminder||'20:00','time','required'),
      'Añadir al calendario'
    ),async data=>{
      const time=String(data.get('time'));
      await saveFile('Kairus-recordatorio.ics',reminderCalendar(time),'text/calendar');
      closePanel();
    });
    return;
  }
  panel(_('Reminders'),form(field('Hora del recordatorio diario','time',ledger.settings.reminder||'20:00','time','required'))+
    (ledger.settings.reminder?action('Desactivar','disable-reminder'):''),
  async data=>{
    const time=String(data.get('time'));
    await scheduleReminder(time,LANG);
    await commit(next=>{next.settings.reminder=time;});
    closePanel();
    toast('Saved');
  });
  if(ledger.settings.reminder) on('#disable-reminder',async ()=>{
    await scheduleReminder('');
    await commit(next=>{next.settings.reminder='';});
    closePanel();
  });
}
function restorePanel() {
  panel(_('Backup & restore'),'<p class="local-note">La copia incluye tus registros, cuentas, categorías, preferencias y comprobantes.</p>'+
    action('Guardar copia JSON','save-backup')+'<label class="local-field">Restaurar una copia<input id="restore-file" type="file" accept=".json,application/json"></label>');
  on('#save-backup',()=>saveFile('Kairus-copia-'+today()+'.json',backup(ledger)));
  $('#restore-file').onchange = async event=>{
    const file=event.target.files[0];
    if(!file) return;
    try {
      requireValue(file.size<=4000000,'Selecciona una copia de hasta 4 MB.');
      const imported=parseBackup(await file.text());
      requireValue(!imported.categories.some(c=>c.id==='transfer'),'La copia contiene una categoría reservada.');
      if($('#restore-file')!==event.target) return;
      panel('Restaurar copia','<p class="local-note">Se reemplazará el registro actual por '+imported.transactions.length+' movimientos de la copia. Guarda primero una copia de tus datos actuales.</p>'+action('Restaurar','confirm-restore'));
      on('#confirm-restore',async ()=>{
        await commit(next=>{
          for(const key of ['settings','accounts','categories','transactions','budgets','recurring']) next[key]=imported[key];
          next.settings.reminder='';
          addMissingCategories(next);
        },{repaint:false});
        applySettings();
        refresh();
        closePanel();
        try { await scheduleReminder(''); } catch(error) { toast(error.message);return; }
        toast('Copia restaurada');
      });
    } catch(error){toast(error.message);}
  };
}

function quickEntryPanel() {
  panel('Registro rápido',form(field('Ejemplo: gasté 18,50 en comida','text','','text','required maxlength="500"'),'Revisar movimiento'),data=>{
    prepareQuickEntry(String(data.get('text')));
  });
}
function prepareQuickEntry(input) {
  const match=input.match(/(?:^|\s|S\/\s*|\$)(\d{1,8}(?:[.,]\d{1,2})?)(?![\d.,])/i);
  requireValue(match,'Escribe un importe. Por ejemplo: gasté 18,50 en comida.');
  const amount=parseMoney(match[1]);
  requireValue(amount>0,'El importe debe ser mayor que cero.');
  const clean=input.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  const type=/\b(cobre|recibi|sueldo|ingreso|earned|salary)\b/.test(clean)?'income':'expense';
  const preferred=type==='income'?'salary':/taxi|bus|pasaje|transporte/.test(clean)?'trans':'food';
  const category=ledger.categories.find(c=>c.id===preferred&&c.type===type&&!c.archived)||ledger.categories.find(c=>c.type===type&&!c.archived);
  requireValue(category,'Crea una categoría para este movimiento.');
  const date=addDate||today();
  closePanel();
  if(!AX.inert) closeAI();
  openAdd(date);
  segSet(type==='income'?1:0);
  pick(document.querySelector('.pn.on [data-k="'+category.id+'"]'));
  ex=(amount/100).toFixed(2);
  $('#nt').value=input.slice(0,500);
  show$();
}
function assistantReply(text) {
  const query=text.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  const m=monthly(ledger,activeMonth());
  if(/como.*presup|how.*budget/.test(query)) return 'Abre Informes y toca Presupuesto mensual para guardar un límite.';
  if(/presup|budget|restante/.test(query)) return m.budget?'Presupuesto: '+price(m.budget)+'\nGastado: '+price(m.expense)+'\nRestante: '+price(m.budget-m.expense):'Aún no definiste un presupuesto para este mes.';
  if(/porcent|percentage|aliment|dining/.test(query)) {
    const spent=m.items.filter(t=>t.type==='expense'&&t.category==='food').reduce((n,t)=>n+t.amount,0);
    return 'Alimentación: '+price(spent)+(m.expense?' · '+(spent/m.expense*100).toFixed(1)+'% de los gastos':'');
  }
  if(/gast|spend|spent|income|ingres|saldo|balance|mes|month/.test(query)) return MONTHS[month]+' '+year+'\nGastos: '+price(m.expense)+'\nIngresos: '+price(m.income)+'\nBalance: '+price(m.balance);
  return 'Puedes consultar los gastos, ingresos y el presupuesto del mes. Usa Registro rápido para preparar un movimiento.';
}
function renderChat() {
  const search=$('#ax-search').value.trim().toLowerCase();
  const list=$('#local-chat');
  list.replaceChildren();
  for(const entry of chat.filter(entry=>!search||entry.text.toLowerCase().includes(search))) {
    const item=document.createElement('p');
    item.className='local-message '+(entry.user?'local-question':'');
    item.textContent=entry.text;
    list.append(item);
  }
  $('.ax-m').scrollTop=$('.ax-m').scrollHeight;
}
async function localSpeech() {
  const Speech=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!Speech?.available) {AXP.focus();toast('El dictado local no está disponible en este dispositivo.');return;}
  const status=await Speech.available({langs:[LOC],processLocally:true});
  if(status!=='available') {AXP.focus();toast('El dispositivo no tiene un idioma disponible para dictado local.');return;}
  const recognition=new Speech();
  recognition.lang=LOC;
  recognition.processLocally=true;
  recognition.onresult=event=>{AXP.value=event.results[0][0].transcript;axSync();};
  recognition.onerror=()=>toast('No se pudo iniciar el dictado local.');
  recognition.start();
}

function addMissingCategories(next) {
  const entries=[...next.transactions,...next.recurring];
  const oldDefaults=new Map(initialState().categories.map(category=>[category.id,category]));
  const aliases={transport:'trans',education:'edu',home:'cabinet'};
  const userCategories=[];
  for(const category of next.categories) {
    const original=builtIns.find(c=>c.id===category.id);
    const formerDefault=oldDefaults.get(category.id);
    const wasDefault=!category.original && formerDefault?.name===category.name && !category.archived;
    if(wasDefault&&aliases[category.id]) {
      for(const entry of entries) if(entry.category===category.id) entry.category=aliases[category.id];
      continue;
    }
    if(original&&original.type!==category.type) {
      const replacement={...category,id:'migrated-'+category.id};
      for(const entry of entries) if(entry.category===category.id&&entry.type===category.type) entry.category=replacement.id;
      userCategories.push(replacement);
    } else if(!category.original && (!wasDefault || !original && entries.some(e=>e.category===category.id))) {
      userCategories.push(category);
    }
  }
  const existing=new Map(userCategories.map(category=>[category.id,category]));
  next.categories=[
    ...builtIns.map(category=>existing.get(category.id)||category),
    ...userCategories.filter(category=>!builtIns.some(c=>c.id===category.id)),
  ];
}

function closeTop() {
  if(!$('#local-sheet').inert){closePanel();return true;}
  if(!AX.inert){closeAI();return true;}
  for(const id of ['#nc','#sub','#sub-name','#sub-cur','#sub-lang']){
    const layer=$(id);
    if(!layer.inert){subClose(layer);return true;}
  }
  if($('#app').classList.contains('open')){sheet(false);return true;}
  if($('#add').classList.contains('aopen')){$('#add').classList.remove('aopen');return true;}
  if(!$('#add').inert){setAdd(false);return true;}
  if(calOn){calClose();return true;}
  if(!$('#v-home').classList.contains('on')){show(0);return true;}
  return false;
}

async function bootLocal() {
  const raw = await readRaw();
  ledger = raw==null ? initialState() : await load(raw);
  if(raw==null) {
    ledger.categories=[];
    ledger.settings.name=NAME.slice(0,24);
    ledger.settings.language=LANG;
    ledger.settings.currency=CUR;
    ledger.settings.iconStyle=ST.add==='mono'?'mono':'color';
    ledger.settings.iconGradient=ST.ic==='solid'?'solid':'gradient';
  }
  addMissingCategories(ledger);
  applySettings();
  resetDraft();
  syncTransactions();
  render(true);

  on('#menu',menu);
  on('#rbd',budgetForm);
  on('#aa',()=>accountForm());
  on('#ma',manageAccounts);
  on('#rhow',()=>panel(_('Accounts'),'<p class="local-note">El saldo inicial es el importe con el que comienzas. Los gastos se restan, los ingresos se suman y las transferencias mueven saldo entre cuentas.</p>'));
  on('#pa',()=>accountForm('',true));
  on('#acb',()=>openAccounts());
  on('#cam',receiptPicker);
  on('#rec',recurrenceChoice);
  on('#ai',quickEntryPanel);
  on('#nok',saveCategory);
  transferTiles[0].onclick=()=>openAccounts('account');
  transferTiles[1].onclick=()=>openAccounts('to');
  on('#keys',event=>{
    const key=event.target.closest('.k')?.dataset.k;
    if(key==='t') datePicker();
    else if(key==='ok') return saveMovement();
    else if(key && (ex.length<100||key==='d')) keyp(key);
  });
  $('#nt').maxLength=500;
  for(const id of ['#list','#cdl']) on(id,event=>{
    const row=event.target.closest('[data-entry]');
    if(row) editMovement(row.dataset.entry);
  });
  for(const id of ['#cp2','#cp3']) on(id,event=>{
    const point=event.target.closest('[data-point]');
    if(point) toast(point.dataset.point);
  });
  const profile=$$('#v-profile .pl button');
  profile[3].onclick=budgetForm;
  profile[4].onclick=reminders;
  profile[6].onclick=()=>saveFile('Kairus-movimientos-'+today()+'.csv',csv(ledger),'text/csv;charset=utf-8').catch(e=>toast(e.message));
  profile[7].onclick=restorePanel;
  profile[8].onclick=()=>panel('Kairus','<p class="local-note">Tus registros se guardan en este dispositivo. Puedes exportar una copia para trasladarlos a otro teléfono.</p>');
  const chatNode=document.createElement('div');
  chatNode.id='local-chat';
  chatNode.setAttribute('role','log');
  chatNode.setAttribute('aria-live','polite');
  $('.ax-m').append(chatNode);
  $('#ax-search').oninput=renderChat;
  on('#ax-clear',()=>{chat=[];AXP.value='';$('#ax-search').value='';axSync();renderChat();});
  on('#ax-send',()=>{
    const text=AXP.value.trim();
    if(!text) return;
    chat.push({user:true,text},{text:assistantReply(text)});
    chat=chat.slice(-40);
    $('#ax-search').value='';
    AXP.value='';
    axSync();
    renderChat();
  });
  on('#ax-mic',localSpeech);
  $('#app').inert=false;
  if(Capacitor.getPlatform()==='android') App.addListener('backButton',()=>{if(!closeTop())App.minimizeApp();});
  addEventListener('keydown',event=>{
    if(event.key==='Escape'&&closeTop()){event.preventDefault();event.stopImmediatePropagation();}
  },true);
}

bootLocal().catch(error=>{
  $('#app').inert=false;
  toast(error.message);
  panel('Abrir Kairus','<p class="local-note">'+safe(error.message)+'</p>'+action('Volver a intentar','retry-open')+action('Exportar datos de recuperación','recover-local'));
  on('#retry-open',()=>location.reload());
  on('#recover-local',async ()=>{
    const raw=await readRaw();
    if(raw) await saveFile('Kairus-recuperacion.json',raw);
  });
});
