import { readFile, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { build } from "esbuild";

const output = process.argv[2] ?? "Kairus.html";
const bundle = await build({
  entryPoints: ["src/original.js"],
  bundle: true,
  format: "iife",
  platform: "browser",
  target: "es2022",
  loader: { ".css": "empty" },
  write: false,
  minify: true,
  legalComments: "none",
});
const script = bundle.outputFiles[0].text.replace(/<\/script/gi, "<\\/script");
const digest = createHash("sha256").update(script).digest("base64");
const css = (await Promise.all([
  readFile("src/original.css", "utf8"),
  readFile("src/local-panels.css", "utf8"),
])).join("\n");
const html = (await readFile("index.html", "utf8"))
  .replace(
    /<meta http-equiv="Content-Security-Policy"[^>]+>/,
    `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'sha256-${digest}'; style-src 'unsafe-inline'; img-src data: blob:; base-uri 'none'; form-action 'none'">`,
  )
  .replace("</head>", () => `<style>${css}</style>\n</head>`)
  .replace('<script type="module" src="./src/original.js"></script>', () => `<script>${script}</script>`);

await writeFile(output, html);
console.log(`HTML autónomo generado: ${output}`);
