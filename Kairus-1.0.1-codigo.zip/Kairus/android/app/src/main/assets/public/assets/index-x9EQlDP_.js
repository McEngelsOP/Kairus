const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BL_fH4Uy.js","./index-Q3jkgeSB.js","./index-C2vz_qkF.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Q3jkgeSB.js";const _=r("Share",{web:()=>t(()=>import("./web-BL_fH4Uy.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
